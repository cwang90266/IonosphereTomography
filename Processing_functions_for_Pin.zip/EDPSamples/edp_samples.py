# -*- coding: utf-8 -*-
"""
EDPSamples: EDP sample sets as specialized xarray.Dataset objects.

Stores altitude (1D), geolocation (lat/lon per point), sampling parameters
(one row per sample, multiple columns e.g. f107, f107_81, ig, ir), the main
EDPs field on (height, geo, sample), and optional Mesh (triangles as geo indices).
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal, Any, MutableMapping
from dateutil.parser import parse

import matplotlib.pyplot as plt

import os
import logging
import subprocess

import numpy as np
import xarray as xr
import math
import pandas as pd

from scipy.spatial import cKDTree
# from EDPSamples.generate_occultation_tri_mesh import generate_occultation_mesh

import pyproj
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator
from tqdm import tqdm

import cartopy.crs as ccrs
import cartopy.feature as cfeature

__all__ = ["EDPSamples"]

# WGS84 (geodetic <-> ECEF for satellite line-of-sight)
_WGS84_A = 6378137.0
_WGS84_E2 = 6.6943799901413165e-3


def _geodetic_to_ecef(
    lat_deg: np.ndarray | float,
    lon_deg: np.ndarray | float,
    alt_m: np.ndarray | float,
    ) -> np.ndarray:
    """Geodetic (deg, deg, m) to ECEF (m); broadcast. Last axis is x, y, z."""
    lat = np.radians(np.asarray(lat_deg, dtype=float))
    lon = np.radians(np.asarray(lon_deg, dtype=float))
    h = np.asarray(alt_m, dtype=float)
    sin_lat = np.sin(lat)
    cos_lat = np.cos(lat)
    cos_lon = np.cos(lon)
    sin_lon = np.sin(lon)
    N = _WGS84_A / np.sqrt(1.0 - _WGS84_E2 * sin_lat * sin_lat)
    x = (N + h) * cos_lat * cos_lon
    y = (N + h) * cos_lat * sin_lon
    z = (N * (1.0 - _WGS84_E2) + h) * sin_lat
    return np.stack(np.broadcast_arrays(x, y, z), axis=-1)


def _ecef_to_geodetic(xyz: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    ECEF (m) to geodetic latitude (deg), longitude (deg), height (m).
    xyz has shape (..., 3). Bowring-style solution, vectorized.
    """
    x = np.asarray(xyz[..., 0], dtype=float)
    y = np.asarray(xyz[..., 1], dtype=float)
    z = np.asarray(xyz[..., 2], dtype=float)
    b = _WGS84_A * np.sqrt(1.0 - _WGS84_E2)
    ep2 = (_WGS84_A * _WGS84_A - b * b) / (b * b)
    p = np.sqrt(x * x + y * y)
    theta = np.arctan2(z * _WGS84_A, p * b)
    st = np.sin(theta)
    ct = np.cos(theta)
    lat = np.arctan2(
        z + ep2 * b * st * st * st,
        p - _WGS84_E2 * _WGS84_A * ct * ct * ct,
    )
    lon = np.arctan2(y, x)
    sin_lat = np.sin(lat)
    N = _WGS84_A / np.sqrt(1.0 - _WGS84_E2 * sin_lat * sin_lat)
    h = p / np.cos(lat) - N
    pole = np.abs(p) < 1.0e-10
    if np.any(pole):
        h_pole = np.abs(z) - b
        lat = np.where(pole, np.sign(z) * (np.pi / 2.0), lat)
        h = np.where(pole, h_pole, h)
    return np.degrees(lat), np.degrees(lon), h


def _inside_spherical_triangle_with_margin(
    query_lats: np.ndarray,
    query_lons: np.ndarray,
    p1: tuple,
    p2: tuple,
    p3: tuple,
    margin_deg: float = 0.0,
) -> np.ndarray:
    """
    Boolean mask: True where (lat, lon) query points fall inside or within
    margin_deg angular degrees of the spherical triangle defined by p1, p2, p3.

    Each edge of the triangle is a great circle arc.  For each edge, a unit
    normal to its plane is computed and oriented toward the opposite vertex.
    A query point is accepted when its dot product with every edge normal
    satisfies n · P ≥ −sin(margin_deg), i.e. it may overshoot the edge by
    up to margin_deg before being rejected.

    Falls back to accepting all points if any edge is degenerate (vertices
    coincide or are antipodal), so callers never receive an empty result from
    a bad triangle alone.

    Parameters
    ----------
    query_lats, query_lons : ndarray, shape (N,)
        Geodetic coordinates of the points to test (degrees).
    p1, p2, p3 : (lat_deg, lon_deg) tuples
        Vertices of the spherical triangle (degrees).
    margin_deg : float
        Angular buffer around the triangle edges (degrees).

    Returns
    -------
    mask : ndarray, shape (N,), bool
    """
    def _unit(lat_d, lon_d):
        lat_r, lon_r = np.radians(lat_d), np.radians(lon_d)
        return np.array([np.cos(lat_r) * np.cos(lon_r),
                         np.cos(lat_r) * np.sin(lon_r),
                         np.sin(lat_r)])

    a = _unit(p1[0], p1[1])
    b = _unit(p2[0], p2[1])
    c = _unit(p3[0], p3[1])

    def _oriented_normal(u, v, ref):
        n = np.cross(u, v)
        norm = np.linalg.norm(n)
        if norm < 1e-9:
            return None          # degenerate edge
        n /= norm
        return n if np.dot(n, ref) >= 0 else -n

    n_ab = _oriented_normal(a, b, c)
    n_bc = _oriented_normal(b, c, a)
    n_ca = _oriented_normal(c, a, b)

    if any(n is None for n in (n_ab, n_bc, n_ca)):
        return np.ones(len(query_lats), dtype=bool)  # degenerate → accept all

    lat_r = np.radians(np.asarray(query_lats, dtype=float))
    lon_r = np.radians(np.asarray(query_lons, dtype=float))
    P = np.column_stack([np.cos(lat_r) * np.cos(lon_r),
                         np.cos(lat_r) * np.sin(lon_r),
                         np.sin(lat_r)])              # (N, 3) unit ECEF

    sin_m = np.sin(np.radians(margin_deg))
    return ((P @ n_ab) >= -sin_m) & ((P @ n_bc) >= -sin_m) & ((P @ n_ca) >= -sin_m)


def ECEFtolla(ECEF):
    # ECEF can be shape (3,) for single point or (3, n) for multiple points
    if ECEF.ndim == 1:
        x, y, z = ECEF[0], ECEF[1], ECEF[2]
    else:
        x, y, z = ECEF[0, :], ECEF[1, :], ECEF[2, :]
    
    # Rest stays the same - pyproj handles arrays automatically
    transformer = pyproj.Transformer.from_crs(
            pyproj.CRS.from_proj4("+proj=geocent +ellps=WGS84 +datum=WGS84"),
            pyproj.CRS.from_proj4("+proj=longlat +ellps=WGS84 +datum=WGS84"),
            always_xy=True
        )
    lon_deg, lat_deg, alt = transformer.transform(1e3*x, 1e3*y, 1e3*z)
    
    return lat_deg, lon_deg, alt

def read_iri_namelist_log(file_path) -> np.array :
    """
    Reads NaN log file generated by iri2020_namelist_driver.
    The results can actually be obtained from the python readout of
    the binary output. This code is to verify that the python read out is
    correct.

    Parameters
    ----------
    file_path : str
        Path to the file 

    Returns idx_iSample_iPts
    -------
 
    """
    idx_iSample_iPts=np.empty((0, 2), int)
    if os.path.exists(file_path) and os.path.getsize(file_path) == 0:
        return idx_iSample_iPts
    with open(file_path, 'r') as f:
        for line in f:
            line = line[len("Ne contains NaN for sample, point")+1:]
            idx_iSample_iPts=np.append(idx_iSample_iPts,[np.array([int(x) for x in line.split()])],axis=0)

    return idx_iSample_iPts

def get_IRI2020_EDP(DateTime: str,
                    altitude: np.ndarray,
                    geolocation: np.ndarray,
                    sampling_parameters: pd.DataFrame,
                    namelist_filename: str = "IRI2020_input_namelist.nml",
                    IRI_output_filename: str = "IRI_output_namelist.dat") -> np.ndarray:

    import tempfile

    IRIPath     = "/home/austinhunter/IonosphereTomography/iri2020_new/src/iri2020/"
    IRIDataPath = IRIPath + "data/"
    exe         = IRIPath + "iri2020_namelist_driver"
    apf107_src  = IRIDataPath + "apf107.dat"
    ig_rz_src   = IRIDataPath + "ig_rz.dat"

    # Each call gets its own temp directory so parallel workers never share
    # IRI_output_namelist.dat or the data symlinks.
    with tempfile.TemporaryDirectory() as tmpdir:
        nml_path = os.path.join(tmpdir, namelist_filename)
        out_path = os.path.join(tmpdir, IRI_output_filename)
        # print(f"Number of points: {geolocation.shape[0]}")
        flag = write_IRI2020_namelist(DateTime, altitude, geolocation,
                                      sampling_parameters, nml_path)
        assert flag == 0, "Fail to write input namelist for IRI2020"

        # Symlinks land inside tmpdir; subprocess cwd=tmpdir keeps everything isolated.
        # Pass only filenames (not absolute paths) — the Fortran driver resolves
        # arguments relative to its working directory.
        cmd = (
            f"ln -s -f {IRIDataPath}mcsat*.dat . ; "
            f"ln -s -f {IRIDataPath}dgrf*.dat . ; "
            f"ln -s -f {IRIDataPath}igrf*.dat . ; "
            f"ln -s -f {IRIDataPath}*.asc . ; "
            f"ln -s -f {apf107_src} . ; "
            f"ln -s -f {ig_rz_src} . ; "
            f"{exe} {namelist_filename} {IRI_output_filename}"
        )

        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=tmpdir)
        if result.returncode != 0 or not os.path.exists(out_path):
            raise RuntimeError(
                f"IRI2020 failed (rc={result.returncode}):\n"
                f"STDOUT: {result.stdout}\nSTDERR: {result.stderr}"
            )

        return read_IRI2020_binary_output(out_path)
    
def write_IRI2020_namelist(DateTime: str,
                    altitude: np.ndarray,
                    geolocation: np.ndarray,
                    sampling_parameters: pd.DataFrame,
                    namelist_filename:str) -> int:
    # 
    # Write the namelist file to be read by IRI2020_namelis_driver
    #
    DateTime = parse(DateTime)
    if not hasattr(DateTime,'hour'):
        DateTime.hour = 0
    if not hasattr(DateTime,'minute'):
        DateTime.minute = DateTime.minute
    if not hasattr(DateTime,'second'):
        DateTime.second = DateTime.second
    #
    #    NAMELIST/EDPSamples/npts, nheight, nSample, height_grid,latitude,longitude, &
    #    idxF107D,idxap,idxIG12,idxRz12,idxfoF2,idxHmF2,idxB0,idxB1, idxHour, &
    #    year, month, day, hour, minute,second,phy_inputs,fill_value 
    #
    fill_value = -99999.
    npts = geolocation.shape[0]
    nheight = altitude.shape[0] 
    nSample = sampling_parameters.shape[0]
    with open(namelist_filename, 'w') as f:
        f.write('&EDPSamples\n')
        f.write(f'fill_value  = {fill_value}\n')    
        f.write(f'npts  = {npts}\n')    
        f.write(f'nheight  = {nheight}\n')    
        f.write(f'nSample  = {nSample}\n')
        f.write('idxHour = 1\n')
        f.write('idxF107D  = 2\n')
        f.write('idxap = 3\n')
        f.write('idxIG12  = 4\n')
        f.write('idxRz12 = 5\n')
        f.write('idxfoF2  = -1\n')
        f.write('idxHmF2 = -1\n')
        f.write('idxB0  = -1\n')
        f.write('idxB1  = -1\n')
        f.write(f'year  = {DateTime.year}\n')
        f.write(f'month  = {DateTime.month}\n')
        f.write(f'day  = {DateTime.day}\n')
        f.write(f'hour  = {DateTime.hour}\n')
        f.write(f'minute  = {DateTime.minute}\n')
        f.write(f'second  = {DateTime.second}\n')

        for idx in range(nheight):           
            f.write(f'height_grid({idx+1})  = {altitude[idx]}\n')
            
        for idx in range(npts):
            f.write(f'latitude({idx+1})  = {geolocation[idx,1]}\n')
            f.write(f'longitude({idx+1})  = {geolocation[idx,0]}\n')

        for idx in range(nSample):
            if np.isnan(sampling_parameters["hour"][idx]):
                f.write(f'phy_inputs(1,{idx+1})  = {fill_value}\n')
            else:
                f.write(f'phy_inputs(1,{idx+1})  = {sampling_parameters["hour"][idx]}\n')
                
            if np.isnan(sampling_parameters["f107"][idx]):
                f.write(f'phy_inputs(2,{idx+1})  = {fill_value}\n')
            else:
                f.write(f'phy_inputs(2,{idx+1})  = {sampling_parameters["f107"][idx]}\n')
                
            if np.isnan(sampling_parameters["ap"][idx]):
                f.write(f'phy_inputs(3,{idx+1})  = {fill_value}\n')
            else:                    
                f.write(f'phy_inputs(3,{idx+1})  = {sampling_parameters["ap"][idx]}\n')
                
            if np.isnan(sampling_parameters["ig12"][idx]):
                f.write(f'phy_inputs(4,{idx+1})  = {fill_value}\n')
            else:
                f.write(f'phy_inputs(4,{idx+1})  = {sampling_parameters["ig12"][idx]}\n')
                
            if np.isnan(sampling_parameters["rz12"][idx]):
                f.write(f'phy_inputs(5,{idx+1})  = {fill_value}\n')
            else:
                f.write(f'phy_inputs(5,{idx+1})  = {sampling_parameters["rz12"][idx]}\n')
        
        f.write('/ \n')

    return 0   

def read_IRI2020_binary_output(IRI_output_filename: str) -> tuple[np.ndarray, np.ndarray]:
    with open(IRI_output_filename, 'rb') as f:
        data = f.read()
    
    # 1. Read Header
    npts = int.from_bytes(data[0:4], byteorder="little", signed=True) 
    nSample = int.from_bytes(data[4:8], byteorder="little", signed=True)
    nheight = int.from_bytes(data[8:12], byteorder="little", signed=True)
    
    # 2. Validation Check (This will catch your error safely)
    expected_bytes = 12 + (nSample * npts * (nheight + 13) * 4)
    actual_bytes = len(data)
    
    if expected_bytes != actual_bytes:
        print(f"Header Variables: nheight={nheight}, npts={npts}, nSample={nSample}")
        raise ValueError(
            f"[!] File size mismatch in {IRI_output_filename}\n"
            f"    Expected: {expected_bytes} bytes based on header.\n"
            f"    Actual:   {actual_bytes} bytes.\n"
            f"    Possible causes: Wrong Endianness, incomplete file write, or Fortran markers."
        )

    # 3. Vectorized Data Parsing (Orders of magnitude faster than nested loops)
    # Read all remaining floats in one go
    all_floats = np.frombuffer(data[12:], dtype=np.float32)
    
    # Reshape based on your loop structure (Sample -> pts -> [heights + features])
    reshaped_data = all_floats.reshape((nSample, npts, nheight + 13))
    
    # Slice out the EDPs and Features
    edps_slice = reshaped_data[:, :, :nheight]       # Shape: (nSample, npts, nheight)
    features_slice = reshaped_data[:, :, nheight:]   # Shape: (nSample, npts, 13)
    
    # Transpose the arrays to match your required output shapes
    # Axis mapping: (Sample=0, Pts=1, Val=2) -> (Val=2, Pts=1, Sample=0)
    edps = np.transpose(edps_slice, (2, 1, 0)).copy()
    feature_edps = np.transpose(features_slice, (2, 1, 0)).copy()
    
    return edps, feature_edps

def plot_polar_mesh(vertices: np.ndarray, triangles: np.ndarray, pole: str = "north", ax=None):
    """
    Plots a triangular mesh in a polar projection centered on the north or south pole.

    Parameters
    ----------
    vertices : np.ndarray, shape (N, 2)
        Array of (longitude, latitude) in degrees.
    triangles : np.ndarray, shape (M, 3)
        Each row contains indices of the triangle corners.
    pole : str, "north" or "south"
        Which pole to center the projection on.
    ax : matplotlib axes, optional
        Existing axes to plot on.
    Returns
    -------
    ax : matplotlib axes
        The axes with the plot.
    """
    if ax is None:
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'}, figsize=(7, 7))
    else:
        fig = ax.figure

    # Convert to radians for polar plotting
    lons = np.deg2rad(vertices[:, 0])
    lats = vertices[:, 1]

    # For north pole: r = 90 - lat, for south pole: r = 90 + lat
    if pole.lower() == "north":
        r = 90 - lats
        theta = lons
        ax.set_theta_zero_location('N')
        ax.set_ylim(0, 90-np.min(vertices[:,1]))
        ax.set_title("Polar Mesh (North Pole)", va='bottom')
    elif pole.lower() == "south":
        r = 90 + lats
        theta = lons
        ax.set_theta_zero_location('S')
        ax.set_ylim(0, 90-np.max(vertices[:,1]))
        ax.set_title("Polar Mesh (South Pole)", va='bottom')
    else:
        raise ValueError("pole must be 'north' or 'south'")

    # Plot each triangle
    for tri in triangles:
        pts = np.array([theta[tri], r[tri]])
        pts = np.column_stack((theta[tri], r[tri]))
        # Close the triangle
        pts = np.vstack([pts, pts[0]])
        ax.plot(pts[:, 0], pts[:, 1], color='k', lw=0.7, alpha=0.7)
        ax.fill(pts[:, 0], pts[:, 1], facecolor='C0', alpha=0.25, edgecolor=None)

    # Plot the vertices
    ax.scatter(theta, r, s=15, c='red', zorder=5, label='Vertices')

    # Optional: grid and labels for degrees
    ax.set_xticks(np.deg2rad(np.arange(0, 360, 45)))
    ax.set_yticks(np.arange(0, 91, 15))
    ax.grid(True, alpha=0.4)
    ax.legend(loc='lower right')
    if pole.lower() == "north":
        ax.set_yticklabels([f"{90-x}°" for x in ax.get_yticks()])
        ax.set_ylim(0, 90-np.min(vertices[:,1]))
    elif pole.lower() == "south":
        ax.set_yticklabels([f"{-90+x}°" for x in ax.get_yticks()])
        ax.set_ylim(0, 90+np.max(vertices[:,1]))
    else:
        raise ValueError("pole must be 'north' or 'south'")

    return ax

def plot_tri_mesh(vertices: np.ndarray, triangles: np.ndarray, ax=None):
    """
    Plot triangular mesh patches and their vertices on a map.

    Parameters
    ----------
    vertices : np.ndarray, shape (N, 2)
        Each row is (longitude, latitude) of a vertex.
    triangles : np.ndarray, shape (M, 3)
        Each row contains indices of the vertices composing one triangle.
    ax : matplotlib.axes.Axes, optional
        Axes on which to plot. If None, a new figure and axes are created.

    Returns
    -------
    ax : matplotlib.axes.Axes
        The axes with the plot.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))
    else:
        fig = ax.figure

    # Plot each triangle
    for tri in triangles:
        tri_pts = vertices[tri]
        # close the polygon by adding the first point to the end
        polygon = np.vstack([tri_pts, tri_pts[0]])
        ax.plot(polygon[:,0], polygon[:,1], 'k-', lw=0.8, alpha=0.7)
        ax.fill(polygon[:,0], polygon[:,1], facecolor='C0', alpha=0.25, edgecolor=None)

    # Plot the vertices
    ax.scatter(vertices[:,0], vertices[:,1], color='red', s=12, label='Vertices', zorder=5)

    ax.set_xlabel("Longitude (deg)")
    ax.set_ylabel("Latitude (deg)")
    ax.set_title("Triangular Mesh")
    ax.autoscale()
    ax.legend()
    ax.grid(True, alpha=0.4)
    return ax

def interp_heights(height_table, height_vector):
    """
    Compute interval indices and linear-interpolation weights for each
    element of `height_vector` against the monotonically increasing grid
    `height_table`.

    Parameters
    ----------
    height_table : (N,) ndarray
        Strictly increasing 1-D array of grid heights.
    height_vector : (M,) ndarray
        Arbitrary 1-D array of query heights.

    Returns
    -------
    idx : (M,) ndarray of int
        For each query height h, idx[k] = i such that
        height_table[i] <= h <= height_table[i+1].
        Values outside the table are clamped to the boundary intervals.
    w : (M, 2) ndarray of float
        Linear-interpolation weights. For a function f sampled on
        height_table, the interpolated value at height_vector[k] is
            f_interp = w[k,0] * f[idx[k]] + w[k,1] * f[idx[k]+1]
        Weights sum to 1 inside the table and are extrapolated linearly
        outside (so one weight may be < 0 or > 1).
    """
    height_table  = np.asarray(height_table,  dtype=float)
    height_vector = np.asarray(height_vector, dtype=float)

    n = height_table.size
    if n < 2:
        raise ValueError("height_table must have at least 2 entries.")

    # searchsorted gives, for each h, the insertion point in the table.
    # Subtract 1 to get the left edge of the containing interval, then
    # clamp so idx is always a valid left index in [0, n-2].
    idx = np.searchsorted(height_table, height_vector, side='right') - 1
    idx = np.clip(idx, 0, n - 2)

    h0 = height_table[idx]
    h1 = height_table[idx + 1]
    dh = h1 - h0                       # all > 0 because table is strictly increasing

    t = (height_vector - h0) / dh      # fractional position in interval
    w = np.empty((height_vector.size, 2), dtype=float)
    w[:, 0] = 1.0 - t                  # weight on f[idx]
    w[:, 1] = t                        # weight on f[idx+1]

    return idx, w

def find_containing_triangles(
    query_latlon,
    geolocation,
    mesh,
    degrees: bool = True,
    k: int = 8,
    max_k: int | None = None,
    eps: float = 1e-10,
    return_bary: bool = False,
):
    """Locate each query point in the spherical triangular mesh.

    Parameters
    ----------
    query_latlon : (M, 2) array_like
        Query points as [lat, lon].
    geolocation : (N, 2) array_like
        Mesh vertices as [lat, lon].
    mesh : (T, 3) array_like of int
        Vertex indices of the three corners of each triangle.
    degrees : bool, default True
        Whether the lat/lon inputs are in degrees.  If False, radians.
    k : int, default 8
        Initial number of nearest-centroid candidates to test per query.
    max_k : int, optional
        Maximum `k` to try if some queries remain unresolved.  Defaults to
        the number of triangles (i.e. brute force as a last resort).
    eps : float, default 1e-10
        Tolerance for the sign test (a point exactly on an edge has a
        scalar triple product equal to zero).
    return_bary : bool, default False
        If True, also return planar barycentric weights for each resolved
        query point.

    Returns
    -------
    triangle_idx : (M,) ndarray of int
        Index into `mesh` of the containing triangle, or -1 if no
        triangle contained the point.
    bary : (M, 3) ndarray, optional
        Planar barycentric weights w_A, w_B, w_C such that
        ``w_A * A + w_B * B + w_C * C`` is the projection of the query
        point onto the plane of triangle (A, B, C).  Only returned when
        ``return_bary=True``.
    """
    query_latlon = np.asarray(query_latlon, dtype=float).reshape(-1, 2)
    geolocation = np.asarray(geolocation, dtype=float).reshape(-1, 2)
    mesh = np.asarray(mesh, dtype=np.int64).reshape(-1, 3)

    n_tri = mesh.shape[0]
    if max_k is None:
        max_k = n_tri

    # Fix: If the inputs are in radians, convert them to degrees first
    # because _geodetic_to_ecef strictly assumes degree inputs.
    if not degrees:
        query_latlon = np.degrees(query_latlon)
        geolocation = np.degrees(geolocation)

    # Fix: Added the missing 0.0 altitude argument for the ECEF conversion
    # Note: Assumes arrays are in [lat, lon] format as per the docstring
    V = _geodetic_to_ecef(geolocation[:, 0], geolocation[:, 1], 0.0)  # (N, 3)
    Q = _geodetic_to_ecef(query_latlon[:, 0], query_latlon[:, 1], 0.0)  # (M, 3)
    M = Q.shape[0]

    # Triangle corners
    A = V[mesh[:, 0]]
    B = V[mesh[:, 1]]
    C = V[mesh[:, 2]]

    # Per-triangle orientation reference (positive for CCW, negative for CW
    # as seen from outside the sphere).  Used to disambiguate the triangle
    # from its antipode in the containment test.
    orient = np.einsum("ij,ij->i", np.cross(A, B), C)  # (T,)

    # Triangle centroids, projected onto the unit sphere
    centroids = (A + B + C) / 3.0
    centroids /= np.linalg.norm(centroids, axis=1, keepdims=True)

    tree = cKDTree(centroids)

    triangle_idx = np.full(M, -1, dtype=np.int64)

    current_k = min(k, n_tri)
    while True:
        unresolved = triangle_idx == -1
        if not np.any(unresolved):
            break

        # k nearest candidate triangles for the still-unresolved queries
        _, cand = tree.query(Q[unresolved], k=current_k)
        if current_k == 1:
            cand = cand[:, None]  # cKDTree drops the trailing axis when k=1

        # Test candidates column by column.  Most points resolve in the
        # first one or two columns, so this is cheap.
        unresolved_idx = np.where(unresolved)[0]
        for col in range(cand.shape[1]):
            still = triangle_idx[unresolved_idx] == -1
            if not np.any(still):
                break
            sub_idx = unresolved_idx[still]
            tris = cand[still, col]

            a = A[tris]
            b = B[tris]
            c = C[tris]
            p = Q[sub_idx]
            r = orient[tris]

            # Each scalar triple product, multiplied by the triangle's
            # orientation reference, must be non-negative for the point
            # to be on the "inside" side of every edge.
            s1 = np.einsum("ij,ij->i", np.cross(a, b), p) * r
            s2 = np.einsum("ij,ij->i", np.cross(b, c), p) * r
            s3 = np.einsum("ij,ij->i", np.cross(c, a), p) * r

            inside = (s1 >= -eps) & (s2 >= -eps) & (s3 >= -eps)
            triangle_idx[sub_idx[inside]] = tris[inside]

        # If anything is still unresolved, widen the search.
        if np.any(triangle_idx == -1) and current_k < max_k:
            current_k = min(current_k * 2, max_k)
        else:
            break

    if not return_bary:
        return triangle_idx

    # Planar barycentric weights for the resolved queries
    bary = np.zeros((M, 3))
    found = triangle_idx != -1
    if np.any(found):
        tris = triangle_idx[found]
        a = A[tris]
        b = B[tris]
        c = C[tris]
        p = Q[found]
        # Project p onto the triangle's plane and solve a 2x2 system in
        # barycentric form.  This is the standard planar barycentric
        # computation; it gives sensible interpolation weights for the
        # small spherical triangles found in geophysical meshes.
        v0 = b - a
        v1 = c - a
        v2 = p - a
        d00 = np.einsum("ij,ij->i", v0, v0)
        d01 = np.einsum("ij,ij->i", v0, v1)
        d11 = np.einsum("ij,ij->i", v1, v1)
        d20 = np.einsum("ij,ij->i", v2, v0)
        d21 = np.einsum("ij,ij->i", v2, v1)
        denom = d00 * d11 - d01 * d01
        wB = (d11 * d20 - d01 * d21) / denom
        wC = (d00 * d21 - d01 * d20) / denom
        wA = 1.0 - wB - wC
        bary[found, 0] = wA
        bary[found, 1] = wB
        bary[found, 2] = wC

    return triangle_idx, bary


class EDPSamples(xr.Dataset):
    """
    Specialized ``xarray.Dataset`` for EDP samples.

    **Coordinates / variables**

    - ``altitude``: 1D along ``height``.
    - ``geolocation``: (geo, 2) latitude and longitude per surface/track point.
    - ``sampling_parameters``: (sample, param) with named parameters
      (e.g. f107, f107_81, ig, ir).
    - ``EDPs``: (height, geo, sample) main field.
    - ``Mesh``: optional (triangle, 3) int indices into ``geo`` for triangle vertices.

    Use :meth:`from_arrays` to construct. Geolocation grids can be built with
    :meth:`genRectangularArea`, :meth:`genPolarArea`, or :meth:`genLineOfSight`.
    Fill ``EDPs`` with :meth:`IRI2020_EDP`, which calls a Fortran driver hook
    (see ``framework/iri2020_driver.py``). Persist with :meth:`saveNetCDF` /
    :meth:`fromNetCDF`.
    """
    __slots__ = ()
    DIM_HEIGHT = "height"
    DIM_GEO = "geo_vertex"
    DIM_SAMPLE = "sample"
    DIM_TRIANGLE = "mesh_triangle"
    DIM_PARAM = "param"
    DIM_GEO_COMPONENT = "lat_lon"
    DIM_VERTEX = "vertex"
    DIM_FEATURE = "feature"

    COORD_ALTITUDE = "altitude"
    VAR_EDPS = "EDPs"
    VAR_GEOLOCATION = "geolocation"
    VAR_SAMPLING = "sampling_parameters"
    VAR_MESH = "Mesh"
    VAR_FEDPS = "feathure_EDPS"
    
    FEATURE_LABEL =("nmf2","hmf2","nmf1","hmf1","nme",
                    "hme","nmd","hmd","hhalf","b0","valley_base","valley_top","b1")
    @staticmethod
    def genRectangularArea(
        minLon: float,
        maxLon: float,
        dLon: float,
        minLat: float,
        maxLat: float,
        dLat: float
    ) -> tuple[np.ndarray,np.ndarray]:
        """
        Evenly spaced latitude–longitude grid over
        ``[minLat, maxLat] × [minLon, maxLon]``.

        Parameters
        ----------
        minLon, maxLon, dLon, minLat, maxLat, dLat  : float
            Bounds in degrees (latitude north, longitude east).

        Returns
        -------
        vertice : Columns are longitude and latitude.
        triangles : Column are indices for vertice of the triangle patches.
        """
        # Make sure the number of grid points in Latitude and 
        # Longitude are odd integers.
        nLat=2*int((maxLat-minLat)/(2*dLat)) + 1
        nLon=2*int((maxLon-minLon)/(2*dLon)) + 1
        #   Create grid of points
        lat_vals = minLat+(maxLat-minLat)*np.arange(nLat )/(nLat-1)
        lon_vals = minLon+(maxLon-minLon)*np.arange(nLon)/(nLon-1)
        vertices = np.column_stack((lon_vals[0]*np.ones(len(lat_vals[::2])),lat_vals[::2]))
        triangles = []
        # The index of the previous column of the vertices.
        TopLeftColumn=0
        for i in range(0,nLon-1,2):
            TopCurrentColumn=TopLeftColumn+len(lat_vals[::2])
            vertices = np.vstack((vertices,np.column_stack((lon_vals[i+1]*np.ones(len(lat_vals[1::2])),lat_vals[1::2]))))
            TopRightColumn=TopCurrentColumn+len(lat_vals[1::2])
            vertices = np.vstack((vertices,np.column_stack((lon_vals[i+2]*np.ones(len(lat_vals[::2])),lat_vals[::2]))))
            for j in range(len(lat_vals[::2]) - 1):
                # Left triangle (v0, v1, v2)
                v0 = TopLeftColumn + j
                v1 = TopLeftColumn + j+ 1
                v2 = TopCurrentColumn + j
                triangles.append([v0, v1, v2])
                # Top triangle (v0, v1, v2)
                v0 = TopLeftColumn + j
                v1 = TopRightColumn + j
                v2 = TopCurrentColumn + j
                triangles.append([v0, v1, v2])
                # Right triangle (v1, v3, v2)
                v0 = TopRightColumn + j+ 1
                v1 = TopCurrentColumn + j
                v2 = TopRightColumn + j
                triangles.append([v0, v1, v2])
                v0 = TopRightColumn + j+ 1
                v1 = TopCurrentColumn + j
                v2 = TopLeftColumn + j+1
                triangles.append([v0, v1, v2])
            TopLeftColumn=TopRightColumn

        triangles = np.array(triangles, dtype=int)
        return vertices, triangles

    @staticmethod
    def genPolarArea(
        pole: Literal["north", "south"],
        minLat: float,
        dLat: float,
        ) -> tuple[np.ndarray,np.ndarray]:
        """
        Evenly spaced grid on a polar cap.

        **North:** latitudes from ``minLat`` to 90°N (``minLat < 90``).

        **South:** latitudes from -90°S to ``-minLat`` with **positive** ``minLat``
        (equatorward edge of the cap, e.g. 66.5° for Antarctic Circle).

        vertice : Columns are longitude and latitude.
        triangles : Column are indices for vertice of the triangle patches.
        """
        # Make sure the number of grid points in Latitude and 
        # Longitude are odd integers.
        if pole == "north":
            nLat=int((90-minLat)/dLat) + 1
            lat_vals = minLat+(90-minLat)*np.arange(nLat )/(nLat-1)        
        elif pole == "south":
            nLat=int((minLat+90)/dLat) + 1
            lat_vals = minLat-(minLat+90)*np.arange(nLat )/(nLat-1)        
        else:
            raise ValueError(f"Invalid pole: {pole}")

        dLon=60
        lon_vals=np.arange(0, 360, dLon)
        vertices = np.column_stack((np.array(0),lat_vals[-1]))
        vertices = np.vstack((vertices,
                np.column_stack((lon_vals,lat_vals[-2]*np.ones(len(lon_vals))))))
        triangles = []
        #print(vertices)
        # Triangles with poles as a vertex.
        for i in range(len(lon_vals)):
            v0 = 0
            v1 = i+1
            if i == len(lon_vals)-1:
                v2=1
            else:
                v2 = i+2
            triangles.append([v0, v1, v2])
            #print(triangles)

        StartPreviousRing=1
        dArc_Previous=0.0
        for j in range(len(lat_vals)-3,-1,-1):
            dArc_Current=np.cos(lat_vals[j]*math.pi/180.)*dLon*math.pi/180.
            if dArc_Current>1.1*dArc_Previous:
                # Longitude grid doubles with each decrease in latitude
                dArc_Previous=dArc_Current
                dLon=dLon/2
                StartCurrentRing=StartPreviousRing+len(lon_vals)
                lon_vals=np.arange(0, 360, dLon)
                vertices = np.vstack((vertices,
                    np.column_stack((lon_vals,lat_vals[j]*np.ones(len(lon_vals))))))
                #print(vertices)
                for i in range(0,len(lon_vals),2):
                    ip=int(i/2)
                    v0 = StartCurrentRing+i
                    v1 = StartPreviousRing+ip
                    v2 = StartCurrentRing+i+1
                    triangles.append([v0, v1, v2])
                    v0 = StartPreviousRing+ip
                    v1 = StartCurrentRing+i+1
                    if i==len(lon_vals)-2:
                        v2 = StartPreviousRing
                    else:
                        v2 = StartPreviousRing+ip+1
                    triangles.append([v0, v1, v2])
                    v0 = StartCurrentRing+i+1
                    if i == len(lon_vals)-2:
                        v1 = StartPreviousRing
                        v2 = StartCurrentRing
                    else:
                        v1 = StartPreviousRing+ip+1
                        v2 = StartCurrentRing+i+2
                    triangles.append([v0, v1, v2])
            else:
                # Longitude grid stays constant
                StartCurrentRing=StartPreviousRing+len(lon_vals)
                vertices = np.vstack((vertices,
                    np.column_stack((lon_vals,lat_vals[j]*np.ones(len(lon_vals))))))
                for i in range(0,len(lon_vals),2):
                    v0 = StartCurrentRing+i
                    v1 = StartPreviousRing+i
                    v2 = StartCurrentRing+i+1
                    triangles.append([v0, v1, v2])
                    v0 = StartPreviousRing+i
                    v1 = StartCurrentRing+i+1
                    v2 = StartPreviousRing+i+1
                    triangles.append([v0, v1, v2])
                    v0 = StartPreviousRing+i+1
                    v1 = StartCurrentRing+i+1
                    if i==len(lon_vals)-2:
                        v2 = StartPreviousRing
                    else:
                        v2 = StartPreviousRing+i+2
                    triangles.append([v0, v1, v2])
                    v0 = StartCurrentRing+i+1
                    if i == len(lon_vals)-2:
                        v1 = StartPreviousRing
                        v2 = StartCurrentRing
                    else:
                        v1 = StartPreviousRing+i+2
                        v2 = StartCurrentRing+i+2
                    triangles.append([v0, v1, v2])
            
            #print(triangles)
            StartPreviousRing=StartCurrentRing

        return vertices, triangles
    
    @staticmethod
    def rayTangent(LEO, GNSS, units='km'):
        """Calculates the tangent points and altitude of the raypath."""
        v = LEO - GNSS
        t_s = np.clip(-np.sum(v * GNSS, axis=0) / np.sum(v * v, axis=0), 0.0, 1.0)
        tangent_point = GNSS + v * t_s[np.newaxis, :]
        p = np.linalg.norm(tangent_point, axis=0)
        
        # Convert to meters for _ecef_to_geodetic
        tp_m = tangent_point * 1000.0 if units == 'km' else tangent_point
        
        # _ecef_to_geodetic expects shape (..., 3) so we transpose tp_m
        _, _, alt_m = _ecef_to_geodetic(tp_m.T)
        
        # Convert altitude back to requested units
        alt = alt_m / 1000.0 if units == 'km' else alt_m

        return tangent_point, p, alt

    @staticmethod
    def get_occultation_extrema(LEO, GNSS, alt_limit=1800.0, r_earth_km=6371.0):
        """
        Analytically computes 3 bounding points (lat, lon) by finding the tangent 
        point of the highest valid ray, and the entry/exit points of the deepest ray.
        """
        # 1. Calculate tangent points and filter by valid altitude limits
        tangent_point, _, tangent_alt = EDPSamples.rayTangent(LEO, GNSS, units='km')
        
        valid_mask = (tangent_alt >= 0) & (tangent_alt <= (alt_limit))
        if not np.any(valid_mask):
            raise ValueError(f"No tangent points found within bounds [0, {alt_limit}] km.")
            
        LEO_v = LEO[:, valid_mask]
        GNSS_v = GNSS[:, valid_mask]
        Tan_v = tangent_point[:, valid_mask]
        alts_v = tangent_alt[valid_mask]
        
        # 2. Identify highest and lowest tangent points
        idx_high = np.argmax(alts_v)
        idx_low = np.argmin(alts_v)
        
        # 3. p1: Tangent point of the highest altitude ray
        ecef_p1 = Tan_v[:, idx_high]
        
        # 4. p2 & p3: Endpoints of the lowest ray at the alt_limit boundary
        leo_low = LEO_v[:, idx_low]
        gnss_low = GNSS_v[:, idx_low]
        v_low = leo_low - gnss_low
        
        R_target = r_earth_km + alt_limit
        a = np.dot(v_low, v_low)
        b = 2.0 * np.dot(gnss_low, v_low)
        c = np.dot(gnss_low, gnss_low) - (R_target ** 2)
        
        discriminant = b**2 - 4*a*c
        if discriminant < 0:
            raise ValueError("The deepest ray does not intersect the altitude limit shell.")
            
        t1 = (-b - np.sqrt(discriminant)) / (2 * a)
        t2 = (-b + np.sqrt(discriminant)) / (2 * a)
        
        ecef_p2 = gnss_low + v_low * t1  # Entry point
        ecef_p3 = gnss_low + v_low * t2  # Exit point
        
        # 5. Convert ECEF points back to Lat/Lon using built-in _ecef_to_geodetic
        points_ecef = np.column_stack((ecef_p1, ecef_p2, ecef_p3))
        pts_m = points_ecef.T * 1000.0  # Transpose to (3,3) for the coordinate function
        
        lats, lons, _ = _ecef_to_geodetic(pts_m)
        
        p1 = (lats[0], lons[0])
        p2 = (lats[1], lons[1])
        p3 = (lats[2], lons[2])
        
        return p1, p2, p3

    @staticmethod
    def genGlobalArea(dSpace: float) -> tuple[np.ndarray, np.ndarray]:
        """
        Approximately equal-area triangular mesh covering the entire globe.
    
        Uses a Fibonacci sphere lattice for near-uniform vertex distribution and
        a convex-hull triangulation (equivalent to Delaunay on the sphere surface)
        for connectivity.  Unlike ``genRectangularArea(-180,180,dLon,-90,90,dLat)``,
        this mesh avoids polar over-sampling: every triangle has a similar physical
        area regardless of latitude.
    
        Parameters
        ----------
        dSpace : float
            Target great-circle spacing between adjacent vertices in degrees.
            Smaller values produce finer meshes.  For reference, dSpace=5 gives
            roughly the same mid-latitude density as a 5°×5° rectangular grid
            but with ~75 % fewer vertices at the poles.
    
        Returns
        -------
        vertices : ndarray, shape (N, 2)
            Columns are [longitude, latitude] in degrees, matching the convention
            used by ``genRectangularArea`` and ``genPolarArea``.
        triangles : ndarray, shape (T, 3)
            Triangle connectivity — each row holds three indices into ``vertices``.
        """
        from scipy.spatial import ConvexHull
    
        # Number of vertices so that the average inter-vertex arc ≈ dSpace degrees.
        # Surface area of the unit sphere = 4π sr; each vertex "owns" roughly
        # dSpace_rad² of solid angle, so N ≈ 4π / dSpace_rad².
        dSpace_rad = np.radians(dSpace)
        n_pts = max(12, int(round(4.0 * np.pi / dSpace_rad ** 2)))
    
        # Fibonacci (Vogel's) lattice — the tightest quasi-uniform packing on S².
        # The golden angle (≈ 137.5°) ensures no two points share the same longitude
        # spacing, eliminating the meridional banding that plagues regular grids.
        golden = np.pi * (np.sqrt(5.0) - 1.0)       # golden angle in radians
        idx    = np.arange(n_pts, dtype=float)
    
        # Map index linearly onto sin(lat) ∈ (−1, 1) for equal-area latitude spacing:
        # equal steps in sin(lat) → equal-area latitude bands.
        sin_lat = 1.0 - 2.0 * (idx + 0.5) / n_pts
        lat_deg = np.degrees(np.arcsin(sin_lat))
    
        # Longitude spirals by one golden angle per point.
        lon_deg = np.degrees(golden * idx % (2.0 * np.pi)) - 180.0   # → (−180, 180]
    
        # ECEF unit-sphere coordinates (R = 1).
        cos_lat = np.sqrt(np.clip(1.0 - sin_lat ** 2, 0.0, 1.0))
        lon_rad = np.radians(lon_deg)
        xyz = np.column_stack([
            cos_lat * np.cos(lon_rad),
            cos_lat * np.sin(lon_rad),
            sin_lat,
        ])
    
        # ConvexHull of points on the unit sphere ≡ Delaunay triangulation on S².
        # This sidesteps the periodic-boundary problem at lon = ±180° that plagues
        # 2-D Delaunay approaches.
        hull = ConvexHull(xyz)
    
        # scipy guarantees outward-pointing face normals, but enforce CCW winding
        # explicitly so downstream code (tripcolor, barycentric tests) is consistent.
        simplices = hull.simplices.copy()
        v0 = xyz[simplices[:, 0]]
        v1 = xyz[simplices[:, 1]]
        v2 = xyz[simplices[:, 2]]
        normals   = np.cross(v1 - v0, v2 - v0)          # (T, 3)
        centroids = (v0 + v1 + v2) / 3.0                # (T, 3)
        flip = (normals * centroids).sum(axis=1) < 0     # dot product per triangle
    
        # Swap columns 1 and 2 on every flipped triangle (vectorised, no aliasing).
        simplices[flip, 1], simplices[flip, 2] = (
            simplices[flip, 2].copy(),
            simplices[flip, 1].copy(),
        )
    
        vertices  = np.column_stack([lon_deg, lat_deg])
        triangles = simplices.astype(int)
        return vertices, triangles
    @staticmethod
    def generate_occultation_mesh(pt1=None, pt2=None, pt3=None, filename=None, dLat=0.5, dLon=0.5, alt_limit=600.0):
        """
        Generates a rectangular grid mesh of vertices (lat, lon) aligned with an 
        occultation geometry.
        """
        from TEC_model.podTc_file_processing import parse_podTc2_nc_file
        
        if filename is not None:
            data = parse_podTc2_nc_file(filename)
            pt1, pt2, pt3 = EDPSamples.get_occultation_extrema(
                data['LEO'], data['GNSS'], alt_limit=alt_limit
            )
            
        if pt1 is not None and pt2 is not None and pt3 is not None:
            target_res = (dLat + dLon) / 2.0
            
            # 1. Convert to Cartesian and normalize to unit vectors using built-in function
            v1 = _geodetic_to_ecef(pt1[0], pt1[1], 0.0)
            v1 = v1 / np.linalg.norm(v1)
            
            v2 = _geodetic_to_ecef(pt2[0], pt2[1], 0.0)
            v2 = v2 / np.linalg.norm(v2)
            
            v3 = _geodetic_to_ecef(pt3[0], pt3[1], 0.0)
            v3 = v3 / np.linalg.norm(v3)
            
            # 2. Calculate Great Circle distances
            e1 = np.degrees(np.arccos(np.clip(np.dot(v1, v2), -1.0, 1.0)))
            e2 = np.degrees(np.arccos(np.clip(np.dot(v2, v3), -1.0, 1.0)))
            e3 = np.degrees(np.arccos(np.clip(np.dot(v3, v1), -1.0, 1.0)))
            max_edge = max(e1, e2, e3)
            
            N = max(1, int(np.ceil(max_edge / target_res)))
            
            vertices_list = []
            indices = {}
            idx_counter = 0
            
            for i in range(N + 1):
                for j in range(N + 1 - i):
                    k = N - i - j
                    w1, w2, w3 = i / N, j / N, k / N
                    
                    # 3. Interpolate strictly in 3D space and normalize back to sphere
                    interp_v = w1 * v1 + w2 * v2 + w3 * v3
                    interp_v = interp_v / np.linalg.norm(interp_v)
                    
                    # 4. Convert back to Lat/Lon
                    # Scale by Earth radius so Bowring algo processes it accurately
                    lat_arr, lon_arr, _ = _ecef_to_geodetic(interp_v * _WGS84_A)
                    
                    # Extract floats
                    lat, lon = float(lat_arr), float(lon_arr)
                    
                    vertices_list.append([lon, lat])
                    indices[(i, j)] = idx_counter
                    idx_counter += 1
                    
            vertices = np.array(vertices_list)
            
            triangles = []
            for i in range(N):
                for j in range(N - i):
                    v0 = indices[(i, j)]
                    v1 = indices[(i + 1, j)]
                    v2 = indices[(i, j + 1)]
                    triangles.append([v0, v1, v2])
                    
                    if j < N - i - 1:
                        v0 = indices[(i + 1, j)]
                        v1 = indices[(i + 1, j + 1)]
                        v2 = indices[(i, j + 1)]
                        triangles.append([v0, v1, v2])
                        
            triangles = np.array(triangles, dtype=int)
        else:
            raise ValueError("You must provide either (pt1, pt2, pt3) OR a valid (filename).")
            
        return vertices, triangles, pt1, pt2, pt3
    @staticmethod
    def genLineOfSight(
        lat1: float,
        lon1: float,
        alt1_m: float,
        lat2: float,
        lon2: float,
        alt2_m: float,
        num_points: int,
    ) -> tuple[np.ndarray,np.ndarray]:
        """
        Geolocations along the straight **ECEF** chord between two satellites
        (WGS84 geodetic inputs: degrees, degrees, metres above ellipsoid).

        Parameters
        ----------
        lat1, lon1, alt1_m
            First satellite.
        lat2, lon2, alt2_m
            Second satellite.
        num_points : int
            Samples along the segment, **including both endpoints** (>= 2).

        Returns
        -------
        ndarray, vertice (num_points, 2)
            Latitude and longitude in degrees. Height along the path is not stored.
        ndarray, segmenta (num_segment,2)
        """
        if num_points < 2:
            raise ValueError("num_points must be >= 2")
        r0 = np.asarray(_geodetic_to_ecef(lat1, lon1, alt1_m), dtype=float).reshape(3)
        r1 = np.asarray(_geodetic_to_ecef(lat2, lon2, alt2_m), dtype=float).reshape(3)
        t = np.linspace(0.0, 1.0, num_points, dtype=float)[:, np.newaxis]
        chord = (1.0 - t) * r0 + t * r1
        lat_deg, lon_deg, _h = _ecef_to_geodetic(chord)
        vertice = np.column_stack([np.asarray(lat_deg).ravel(), np.asarray(lon_deg).ravel()]
        ).astype(float)
        segment = np.column_stack((np.arange(num_points-1),np.arange(1,num_points)))
        return vertice, segment

    def __init__(cls,
        DateTime: str,
        geo_type : Literal["Point", "Rectangle", "Polar", "Occultation", "Global"],
        altitude: np.ndarray,
        sampling_parameters: pd.DataFrame,
        evaluate_iri: int = None,
        minLon: float = None,
        maxLon: float = None,
        dLon: float = None,
        minLat: float = None,
        maxLat: float = None,
        dLat: float = None,
        Lon: float = None,
        Lat: float = None,
        filename: str = None,
        pt1: tuple = None,
        pt2: tuple = None,
        pt3: tuple = None,
        alt_limit: float = 700.0,
        edps: np.ndarray = None,
        feature_edps: np.ndarray = None,
        equal_spaced: bool = False,
        attrs = None):
        #) -> EDPSamples:
        """
        Build an ``EDPSamples`` dataset.

        Parameters
        ----------
        geo_type : Literal["Point","Rectangle","Polar","Occultation","Global"], type of 2D grid
        altitude : (n_height,) array
            1D altitude (or height coordinate) for each index along ``height``.
        sampling_parameters: pd.Dataframe,
        evaluate_iri: int flag. =1 if IRI2020 is to be evaluated.
        minLon: float =None, minimum longitude for rectangular lat, lon grid.
        maxLon: float =None, maximum longitude for rectangular lat, lon grid.
        dLon: float =None, logitudinal step for rectangular lat, lon grid.
        minLat: float =None, minimum latitude for rectangular lat, lon grid. Also
                for polar grid.
        maxLat: float =None, maximum latitude for rectangular lat, lon grid.
        dLat: float =None, Latitude step for rectangular and polar grid.
        Lon: float = None, Longitude of single control point.
        Lat: float = None, Latitude of single control point.
        filename: str = None, filename for the RO data (needed only if pt1,pt2,pt3 are missing)
        pt1: tuple = None, points that define the triangular region for a RO
        pt2: tuple = None, points that define the triangular region for a RO
        pt3: tuple = None, points that define the triangular region for a RO
        alt_limit: float = 700.0, altitude defining the traingular region assciated with a RO.
                                  (needed only if pt1,pt2,pt3 are missing)
        edps: numpy array, sample edps
        feature_edps: np.ndarray = None, sample features of edps
        equal_spaced: bool = False, if True, generates a globally equal-spaced grid. If False, uses dLat/dLon.
        attrs : mapping, optional Dataset attributes.
        """
        if attrs is None:
            attrs = sampling_parameters.attrs
            attrs["sample_param_attrs"]=list(sampling_parameters.attrs.keys())
            
        sample_param_value=sampling_parameters.to_numpy()
        sample_Param_name=sampling_parameters.columns
        n_sample = sampling_parameters.shape[0]
        
        altitude = np.asarray(altitude)
        match geo_type:
            case "Point":
                if Lon == None or Lat == None:
                    raise ValueError("For geo_type point, Lon and Lat cannot be None.")
                geolocation =np.array([[Lon,Lat]])
                mesh = None
            case "Rectangle":
                if minLon == None or maxLon == None or dLon == None or minLat == None or maxLat == None or dLat == None:
                    raise ValueError("For geo_type Rectangle, minLon, maxLon, dLon, minLat, maxLat, and dLat cannot be None.")
                geolocation, mesh = cls.genRectangularArea(minLon, maxLon, dLon, minLat, maxLat, dLat)
            case "Polar":
                if minLat == None or dLat == None :
                    raise ValueError("For geo_type Polar, minLat, and dLat cannot be None.")
                if minLat > 0:
                    pole="north"
                else:
                    pole="south"
                geolocation, mesh = cls.genPolarArea(pole,minLat,dLat)
            case "Occultation":
                if filename is None and (pt1 is None or pt2 is None or pt3 is None):
                    raise ValueError("For geo_type Occultation, you must provide either a 'filename' or all three points ('pt1', 'pt2', 'pt3').")
                if dLat is None or dLon is None:
                    print("For geo_type Occultation, dLat and dLon assumed to be 5 deg.")
                    geolocation, mesh, pt1, pt2, pt3 = cls.generate_occultation_mesh(
                        pt1=pt1, pt2=pt2, pt3=pt3, 
                        filename=filename, 
                        dLat=5, dLon=5, 
                        alt_limit=alt_limit
                    )
                else:
                # vertices = geolocation (lon, lat array), triangles = mesh (indices array)
                    geolocation, mesh, pt1, pt2, pt3 = cls.generate_occultation_mesh(
                        pt1=pt1, pt2=pt2, pt3=pt3, 
                        filename=filename, 
                        dLat=dLat, dLon=dLon, 
                        alt_limit=alt_limit
                    )
            case "Global":
                if equal_spaced:
                    if dLat is None:
                        raise ValueError("For geo_type Global with equal_spaced=True, provide dLat as the target average spacing.")
                    # NOTE: You will need to implement this new method in your class!
                    geolocation, mesh = cls.genGlobalArea(dSpace=dLat)
                else:
                    if dLat is None or dLon is None:
                        raise ValueError("For geo_type Global with equal_spaced=False, both dLat and dLon must be provided.")
                    # Re-use the rectangular area spanning the entire globe
                    geolocation, mesh = cls.genRectangularArea(-180.0, 180.0, dLon, -90.0, 90.0, dLat)
            case _:
                raise ValueError(f"Invalid geo_type: {geo_type}")

            
        if altitude.ndim != 1:
            raise ValueError("altitude must be 1-D")
        n_height = altitude.shape[0]

        if geolocation.ndim != 2 or geolocation.shape[1] != 2:
            raise ValueError("geolocation must have shape (n_geo, 2) for lat, lon")
        n_geo = geolocation.shape[0]
        
        if edps is None or feature_edps is None:
            if evaluate_iri == 1:
                edps, feature_edps = get_IRI2020_EDP(DateTime,altitude,geolocation,sampling_parameters)
            else:
                edps=np.ndarray((n_height,n_geo,n_sample))
                feature_edps=np.ndarray((len(cls.FEATURE_LABEL),n_geo,n_sample))
        else:
            print(f"EDPS: {edps.shape}, N_geo: {n_geo}")
            assert edps.ndim == 3, "EDP sample profile must be 3 dimensional"
            assert edps.shape[0] == n_height, "EDP samples'eading dimension must be height"
            assert edps.shape[1] == n_geo, "EDP sample second dimension must be vertices"
            assert edps.shape[2] == n_sample, "EDP sample last dimension must be param sample"
            assert feature_edps.shape[0] == len(cls.FEATURE_LABEL), "feature_edps samples'eading dimension must be the length of feature labels"
            assert feature_edps.shape[1] == n_geo, "feature_edps second dimension must be vertices"
            assert feature_edps.shape[2] == n_sample, "feature_edps last dimension must be param sample"
            

        coords: MutableMapping[str, Any] = {
            cls.COORD_ALTITUDE: (cls.DIM_HEIGHT, altitude),
            cls.DIM_GEO_COMPONENT: (
                cls.DIM_GEO_COMPONENT,
                np.array(["latitude", "longitude"], dtype=object)),
            cls.DIM_PARAM: (
                cls.DIM_PARAM, sample_Param_name    
            ),
            cls.DIM_FEATURE: (
                cls.DIM_FEATURE, np.array(cls.FEATURE_LABEL)
            )
            #self.DIM_PARAM: (self.DIM_PARAM, sampling_parameters),
        }
        #
        # Define variables
        #
        data_vars: MutableMapping[str, Any] = {
            cls.VAR_GEOLOCATION: (
                (cls.DIM_GEO, cls.DIM_GEO_COMPONENT),
                geolocation,
                {
                    "long_name": "geolocation",
                    "description": "latitude (column 0), longitude (column 1)",
                },
            ),
            cls.VAR_EDPS: (
                (cls.DIM_HEIGHT, cls.DIM_GEO, cls.DIM_SAMPLE),
                edps,
                {"long_name": "EDPs",
                 "description": "electron density profiles samples"}
                ),
            cls.VAR_FEDPS: (
                (cls.DIM_FEATURE, cls.DIM_GEO, cls.DIM_SAMPLE),
                feature_edps,
                {"long_name": "Feature_EDPs",
                 "description": "features of electron density profiles samples"}
                ),
            cls.VAR_SAMPLING: (
                (cls.DIM_SAMPLE,cls.DIM_PARAM),
                sample_param_value,
                {"long name": "sample_input_parameter",
                 "description": "sample inputs for IRI2020 model"}
            ),
        }
        if mesh is not None:
            mesh = np.asarray(mesh, dtype=np.int64)
            if mesh.ndim != 2 or mesh.shape[1] != 3:
                raise ValueError("mesh must have shape (n_triangle, 3)")
            if np.any(mesh < 0) or np.any(mesh >= n_geo):
                raise ValueError("mesh indices must be in [0, n_geo)")
            
            data_vars[cls.VAR_MESH] = (
                (cls.DIM_TRIANGLE, cls.DIM_VERTEX),
                mesh,
                {
                    "long_name": "surface mesh",
                    "description": 
                        "triangles: three vertex indices into the geo dimension"
                },
            )
        attrs['DateTime'] = DateTime
        attrs['geo_type'] = geo_type
            
        match geo_type:
            case "Point":
               attrs["Lon"] = Lon
               attrs["Lat"] = Lat
            case "Rectangle":
                attrs["minLon"] = minLon
                attrs["maxLon"] = maxLon
                attrs["dLon"] = dLon
                attrs["minLat"] = minLat
                attrs["maxLat"] = maxLat
                attrs["dLat"] = dLat
            case "Occultation":
                attrs["filename"] = filename
                attrs["pt1"] = pt1
                attrs["pt2"] = pt2
                attrs["pt3"] = pt3
                # Fixed bug here (dLon/dLat were being forced to 5 below)
                attrs["dLon"] = dLon if dLon is not None else 5
                attrs["dLat"] = dLat if dLat is not None else 5
                attrs["alt_limit"] = alt_limit
            case "Polar":
                attrs["minLat"] = minLat
                attrs["dLat"] = dLat
                if minLat > 0:
                    attrs["pole"] = "north"
                else:
                    attrs["pole"] = "south"
            case "Global":
                # NetCDF cannot save booleans. Convert True/False to 1/0
                attrs["equal_spaced"] = int(equal_spaced) 
                
                # NetCDF also hates 'None' types, so we default them to 0.0 if missing
                attrs["dLat"] = dLat if dLat is not None else 0.0
                attrs["dLon"] = dLon if dLon is not None else 0.0

        super().__init__(
            data_vars=data_vars,
            coords=coords,
            attrs=attrs)

    @classmethod
    def fromNetCDF(cls, path: str | Path, **kwargs: Any) -> EDPSamples:
        """
        Load an ``EDPSamples`` from NetCDF (e.g. written by :meth:`saveNetCDF`).

        The file is read fully into memory, then closed.

        Parameters
        ----------
        path : str or pathlib.Path
            Path to the ``.nc`` file.
        **kwargs
            Forwarded to :func:`xarray.open_dataset` (e.g. ``engine``, ``group``,
            ``decode_times``, ``mask_and_scale``).

        Returns
        -------
        EDPSamples
        """
        with xr.open_dataset(path, **kwargs) as ds:
            ds.load()
            EDPSam = EDPSamples.from_xarray(ds)
            return EDPSam
        
    @classmethod
    def from_xarray(cls, ds) -> EDPSamples:
        assert "DateTime" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (0)."]
        assert "geo_type" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (1)."]

        assert cls.VAR_SAMPLING in ds.data_vars, ["Missing sampling_parameters in loaded dataset."]
        sampling_parameters_xr=ds.data_vars["sampling_parameters"]
        sampling_parameters=sampling_parameters_xr.to_dataframe().unstack()
        sampling_parameters=sampling_parameters.reset_index()
        sampling_parameters.columns=sampling_parameters.columns.droplevel(0)
        sampling_parameters=sampling_parameters.drop(sampling_parameters.columns[0],axis=1)

        assert cls.COORD_ALTITUDE in ds.coords, ["Missing altitude in loaded dataset."]
        altitude_xr = ds.coords["altitude"]
        altitude = altitude_xr.to_numpy()

        assert cls.VAR_EDPS in ds.data_vars, ["Missing EDPs in loaded dataset."]
        assert cls.VAR_FEDPS in ds.data_vars, ["Missing FEDPs in loaded dataset."]
        
        epds_xr = ds.data_vars[cls.VAR_EDPS]
        edps = epds_xr.to_numpy()
        feature_edps_xr = ds.data_vars[cls.VAR_FEDPS]
        feature_edps = feature_edps_xr.to_numpy()
        
        match ds.attrs["geo_type"]:
            case "Point":
               assert "Lon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (2)."]
               assert "Lat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (3)."]
               return EDPSamples(ds.attrs["DateTime"],ds.attrs["geo_type"],
                                altitude, sampling_parameters, 
                                Lon=ds.attrs["Lon"],Lat=ds.attrs["Lon"],
                                edps=edps,feature_edps=feature_edps,attrs=ds.attrs)

            case "LOS":
                assert "LOS_LEO" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (4)."]
                assert "LOS_GNSS" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (5)."]
                assert "LOS_nb_point" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (6)."]
                return EDPSamples(ds.attrs["DateTime"],ds.attrs["geo_type"],
                                altitude, sampling_parameters, 
                                LOS_LEO=ds.attrs["LOS_LEO"],LOS_GNSS=ds.attrs["LOS_GNSS"],
                                LOS_nb_point=ds.attrs["LOS_nb_point"],
                                edps=edps,attrs=ds.attrs)
            case "Occultation":
                assert "filename" in ds.attrs, ["Loaded dataset missing Occultation filename."]
                return EDPSamples(ds.attrs["DateTime"], ds.attrs["geo_type"],
                                altitude, sampling_parameters, 
                                filename=ds.attrs["filename"],
                                pt1=ds.attrs.get("pt1"), pt2=ds.attrs.get("pt2"), pt3=ds.attrs.get("pt3"),
                                dLat=ds.attrs.get("dLat"), dLon=ds.attrs.get("dLon"),
                                edps=edps, attrs=ds.attrs)
            case "Rectangle":
                assert "minLon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (7)."]
                assert "maxLon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (8)."]
                assert "dLon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (9)."]
                assert "minLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (10)."]
                assert "maxLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (11)."]
                assert "dLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (12)."]
                return EDPSamples(ds.attrs["DateTime"],ds.attrs["geo_type"],
                                altitude, sampling_parameters, 
                                minLon=ds.attrs["minLon"],maxLon=ds.attrs["maxLon"],
                                dLon=ds.attrs["dLon"],
                                minLat=ds.attrs["minLat"],maxLat=ds.attrs["maxLat"],
                                dLat=ds.attrs["dLat"],
                                edps=edps,feature_edps=feature_edps,attrs=ds.attrs)
            case "Polar":
                assert "minLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (13)."]
                assert "dLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (14)."]
                return EDPSamples(ds.attrs["DateTime"],ds.attrs["geo_type"],
                                altitude, sampling_parameters,
                                minLat=ds.attrs["minLat"],dLat=ds.attrs["dLat"],
                                edps=edps,feature_edps=feature_edps,attrs=ds.attrs)
            case "Global":
                assert "dLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (15g)."]
                assert "dLon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (16g)."]
                return EDPSamples(ds.attrs["DateTime"], ds.attrs["geo_type"],
                                altitude, sampling_parameters,
                                equal_spaced=bool(ds.attrs.get("equal_spaced", False)),
                                dLat=ds.attrs["dLat"],
                                dLon=ds.attrs["dLon"],
                                edps=edps, feature_edps=feature_edps, attrs=ds.attrs)
            case "Occultation":
                assert "pt1" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (15)."]
                assert "pt2" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (16)."]
                assert "pt3" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (17)."]
                assert "dLat" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (18)."]
                assert "dLon" in ds.attrs, ["Loaded dataset does not have the structure of EDPSamples (19)."]
                return EDPSamples(ds.attrs["DateTime"],ds.attrs["geo_type"],
                                altitude, sampling_parameters, 
                                pt1=ds.attrs["pt1"],pt2=ds.attrs["pt2"],pt3=ds.attrs["pt3"],
                                dLat=ds.attrs["dLat"],dLon=ds.attrs["dLon"],
                                edps=edps,feature_edps=feature_edps,attrs=ds.attrs)
        
        
    def saveNetCDF(self, path: str | Path, **kwargs: Any) -> None:
        """
        Write this dataset to a NetCDF file.

        Parameters
        ----------
        path : str or pathlib.Path
            Output path (typically ``.nc``).
        **kwargs
            Forwarded to :meth:`xarray.Dataset.to_netcdf` (e.g. ``mode``, ``format``,
            ``engine``, ``encoding``).
        """
        self.to_netcdf(path, **kwargs)

    def plot_geolocation(self):
        match self.attrs["geo_type"]:
            case "Point" :
                fig, ax = plt.subplots(figsize=(8, 6))
                # Plot the vertices
                ax.scatter(self.geolocation[:,0], self.geolocation[:,1], color='red', s=12, label='Vertices', zorder=5)
                ax.set_xlabel("Longitude (deg)")
                ax.set_ylabel("Latitude (deg)")
                ax.autoscale()
                ax.legend()
                ax.grid(True, alpha=0.4)
                
            case "Rectangle" | "Occultation":
                plot_tri_mesh(self.geolocation, self.mesh)                
            case "Polar":
                if self.attrs["minLat"] > 0:
                    plot_polar_mesh(self.geolocation, self.mesh, pole= "north")  
                else:
                    plot_polar_mesh(self.geolocation, self.mesh, pole= "south")  
                    
    def plot_mesh_globe(self, tecmax_lat, tecmax_lon, save_path,
                        podTc_data=None, tangent_lla=None, alt_limit=600.0,
                        mesh_scalars=None, target_alt=None, target_sample=0,
                        scalar_cmap='viridis', scalar_label=None):
        """
        Plots the occultation mesh on an orthographic globe. 
        Optionally plots scalar data mapped to the mesh vertices.

        Parameters:
        -----------
        mesh_scalars : str or np.ndarray, optional
            If str, must be 'Ne', 'Median', or 'StdDev'. The function will compute/extract 
            the 1D array automatically based on `target_alt_idx`.
            If np.ndarray, it must be a 1D array of length n_geo.
        target_alt_idx : int, optional
            The altitude index to slice if `mesh_scalars` is a string.
        target_sample : int, optional
            The ensemble sample index to plot if `mesh_scalars` == 'Ne' (default is 0).
        """
        vertices  = self.geolocation  # (n_geo, 2): col 0 = lon, col 1 = lat
        triangles = self.mesh
    
        fig = plt.figure(figsize=(8, 8))
        ax = plt.axes(projection=ccrs.Orthographic(central_longitude=tecmax_lon,
                                                   central_latitude=tecmax_lat))
        ax.set_global()
        ax.add_feature(cfeature.LAND, facecolor='lightgray')
        ax.add_feature(cfeature.OCEAN, facecolor='lightblue')
        ax.add_feature(cfeature.COASTLINE.with_scale('110m'), linewidth=0.5)
        ax.add_feature(cfeature.BORDERS, linestyle=':', linewidth=0.5)
    
        # ---------------------------------------------------------
        # Parse mesh_scalars string and extract/compute data
        # ---------------------------------------------------------
        scalar_data = None
        if isinstance(mesh_scalars, str):
            if target_alt is None:
                raise ValueError("target_alt must be provided if mesh_scalars is a string.")
            
            # Find the index of the closest altitude in the grid
            target_alt_idx = int(np.argmin(np.abs(self.altitude - target_alt)))
            actual_alt = self.altitude[target_alt_idx]
            
            print(f"Requested Alt: {target_alt} km -> Using closest grid Alt: {actual_alt:.2f} km (Index: {target_alt_idx})")
            
            var_req = mesh_scalars.lower()
            
            if var_req in ['ne', 'edp']:
                scalar_data = self.edps[target_alt_idx, :, target_sample]
                if scalar_label is None:
                    scalar_label = f'Electron Density (m⁻³) [Alt: {actual_alt:.1f} km, Sample: {target_sample}]'
            
            elif var_req in ['median']:
                scalar_data = np.nanmedian(self.edps[target_alt_idx, :, :], axis=1)
                if scalar_label is None:
                    scalar_label = f'Median Ne (m⁻³) [Alt: {actual_alt:.1f} km]'
                    
            elif var_req in ['std', 'stddev']:
                scalar_data = np.nanstd(self.edps[target_alt_idx, :, :], axis=1)
                if scalar_label is None:
                    scalar_label = f'Ne Std Dev (m⁻³) [Alt: {actual_alt:.1f} km]'
                    
            else:
                raise ValueError(f"Unknown mesh_scalars string: '{mesh_scalars}'. Try 'Ne', 'Median', or 'StdDev'.")
        else:
            # Fallback if the user passes a pre-sliced numpy array directly
            scalar_data = mesh_scalars
            if scalar_label is None:
                scalar_label = 'Data Value'

        # ---------------------------------------------------------
        # Plot the Mesh (Filled or Wireframe)
        # ---------------------------------------------------------
        if scalar_data is not None:
            if len(scalar_data) != vertices.shape[0]:
                raise ValueError(f"Extracted/Provided data must have length {vertices.shape[0]} (n_geo), got {len(scalar_data)}")
            
            print(f"Plotting filled mesh using variable type: {mesh_scalars}")
            
            # Switch back to ccrs.Geodetic() so the 360 -> 0 connection wraps correctly
            tc = ax.tripcolor(vertices[:, 0], vertices[:, 1], triangles, scalar_data,
                              transform=ccrs.Geodetic(), cmap=scalar_cmap, 
                              shading='flat', edgecolors='face', alpha=0.85)
            
            # Match the triplot transform to Geodetic as well
            ax.triplot(vertices[:, 0], vertices[:, 1], triangles,
                       transform=ccrs.Geodetic(), color='black', linewidth=0.3, alpha=0.4)
            
            cbar = plt.colorbar(tc, ax=ax, orientation='horizontal', shrink=0.7, pad=0.05)
            cbar.set_label(scalar_label)
            
        else:
            print("Attempting to plot occultation mesh region (wireframe only)...")
            ax.triplot(vertices[:, 0], vertices[:, 1], triangles,
                       transform=ccrs.Geodetic(), color='darkorange', linewidth=0.8, alpha=0.7)
    
        # ---------------------------------------------------------
        # Plot Satellite / Ray geometry
        # ---------------------------------------------------------
        if podTc_data is not None:
            transformer = pyproj.Transformer.from_crs(
                pyproj.CRS.from_proj4("+proj=geocent +ellps=WGS84 +datum=WGS84"),
                pyproj.CRS.from_proj4("+proj=longlat +ellps=WGS84 +datum=WGS84"),
                always_xy=True
            )
    
            leo  = podTc_data['LEO']   # (3, N)
            gnss = podTc_data['GNSS']  # (3, N)
    
            lon_leo,  lat_leo,  _ = transformer.transform(leo[0, 0]  * 1e3, leo[1, 0]  * 1e3, leo[2, 0]  * 1e3)
            lon_gnss, lat_gnss, _ = transformer.transform(gnss[0, 0] * 1e3, gnss[1, 0] * 1e3, gnss[2, 0] * 1e3)
    
            ax.plot(lon_leo,  lat_leo,  transform=ccrs.Geodetic(),
                    color='g', marker='^', markersize=6, label='LEO Start')
            ax.plot(lon_gnss, lat_gnss, transform=ccrs.Geodetic(),
                    color='r', marker='s', markersize=6, label='GNSS Start')
    
            lons_leo,  lats_leo,  _ = transformer.transform(leo[0, :]  * 1e3, leo[1, :]  * 1e3, leo[2, :]  * 1e3)
            lons_gnss, lats_gnss, _ = transformer.transform(gnss[0, :] * 1e3, gnss[1, :] * 1e3, gnss[2, :] * 1e3)
    
            ax.plot(lons_leo,  lats_leo,  transform=ccrs.Geodetic(),
                    color='g', linewidth=0.8, alpha=0.6)
            ax.plot(lons_gnss, lats_gnss, transform=ccrs.Geodetic(),
                    color='r', linewidth=0.8, alpha=0.6)
    
        if tangent_lla is not None:
            mask = tangent_lla[2, :] < alt_limit * 1e3
            ax.plot(tangent_lla[1, mask], tangent_lla[0, mask],
                    transform=ccrs.Geodetic(), color='m', linewidth=2, label='Tangent Path')
    
        plt.title(f"Occultation Mesh Geometry Below {alt_limit} km")
    
        if podTc_data is not None:
            plt.legend(loc='upper right')
    
        fig.savefig(save_path, dpi=300, bbox_inches='tight')
        

    def interp(self, positions: np.array, 
               coordinate: Literal["lla","ecef"] = "lla") -> tuple[np.ndarray,  np.ndarray, np.ndarray,  np.ndarray]:
        if coordinate == "ecef":
            latitude,longitude, altitude = _ecef_to_geodetic(positions)
        else:
            latitude = positions[:,0]
            longitude = positions[:,1]
            altitude = positions[:,2]
            positions = _geodetic_to_ecef(latitude,longitude, altitude)
            
        idx_alt,weight_alt = interp_heights(self.altitude, altitude)
        
        match self.attrs["geo_type"]:
            case "Point": 
                return idx_alt, weight_alt
            case "Rectangle" | "Polar" | "Occultation" :
                idx_mesh, weight_mesh = find_containing_triangles(
                    np.column_stack([latitude,longitude]),
                    self.geolocation,
                    self.mesh,
                    return_bary = True,
                    )
                return idx_alt, weight_alt, idx_mesh, weight_mesh
            
    def get_observation_operator(self, podTc2_data: dict, num_segments: int = 1000) -> np.ndarray:
        """
        Generates the Observation Operator (H matrix) for the Kalman Filter.
        Maps the integration path of RO rays to the flattened state vector.
        
        Parameters
        ----------
        podTc2_data : dict
            Dictionary containing 'LEO' and 'GNSS' ECEF coordinate arrays.
        num_segments : int, default 1000
            Number of segments to divide each ray into for integration.
            
        Returns
        -------
        H : np.ndarray
            Observation matrix of shape (n_rays, n_state_vars), where 
            n_state_vars = n_height * n_geo.
        """
        from scipy.spatial import cKDTree
        import pyproj
        
        altitude = self.altitude
        geolocation = self.geolocation
        n_height = len(altitude)
        n_geo = geolocation.shape[0]
        n_state_vars = n_height * n_geo
        
        LEO = podTc2_data['LEO']
        GNSS = podTc2_data['GNSS']
        n_rays = LEO.shape[1]
        
        # Initialize the H matrix (n_observations x n_state_variables)
        H = np.zeros((n_rays, n_state_vars), dtype=np.float32)
        
        transformer = pyproj.Transformer.from_crs(
            pyproj.CRS.from_proj4("+proj=geocent +ellps=WGS84 +datum=WGS84"),
            pyproj.CRS.from_proj4("+proj=longlat +ellps=WGS84 +datum=WGS84"),
            always_xy=True
        )

        # Cache the KDTree for the "NearestNDInterpolator" fallback outside the mesh
        if n_geo > 1:
            tree = cKDTree(geolocation)

        for i in tqdm(range(n_rays), desc="Building H Matrix"):
            t = np.linspace(0, 1, num_segments)
            ray_points = GNSS[:, i:i+1] + (LEO[:, i:i+1] - GNSS[:, i:i+1]) * t
            
            diffs = np.diff(ray_points, axis=1)
            dl_m = np.linalg.norm(diffs, axis=0) * 1000.0  # Segment lengths in meters
            
            midpoints = (ray_points[:, :-1] + ray_points[:, 1:]) / 2.0
            
            lons, lats, alts_m = transformer.transform(
                midpoints[0, :] * 1e3,
                midpoints[1, :] * 1e3,
                midpoints[2, :] * 1e3
            )
            alts_km = alts_m / 1000.0
            
            # 1. Mask out segments completely outside our altitude bounds (left=0.0, right=0.0)
            valid_mask = (alts_km >= altitude[0]) & (alts_km <= altitude[-1])
            if not np.any(valid_mask):
                continue
                
            dl_m_v = dl_m[valid_mask]
            lats_v = lats[valid_mask]
            lons_v = lons[valid_mask]
            alts_km_v = alts_km[valid_mask]
            
            # 2. Get 1D Altitude Indices and Weights
            idx_alt, w_alt = interp_heights(altitude, alts_km_v)
            a_idx0 = idx_alt
            a_idx1 = idx_alt + 1
            aw0 = w_alt[:, 0]
            aw1 = w_alt[:, 1]
            
            # 3. Get Spatial Indices and Weights
            if n_geo == 1:
                # Spherical Symmetry: Add weight purely based on altitude to the single column
                # State index mapping: h_idx * 1 + 0 = h_idx
                np.add.at(H[i], a_idx0, dl_m_v * aw0)
                np.add.at(H[i], a_idx1, dl_m_v * aw1)
                
            else:
                # Mesh Geometry: 2D Spatial mapping
                tri_idx, bary = find_containing_triangles(
                    np.column_stack([lats_v, lons_v]), 
                    geolocation, 
                    self.mesh, 
                    return_bary=True
                )
                
                inside = tri_idx != -1
                outside = tri_idx == -1
                
                # --- A. Handle points INSIDE the mesh (Linear Barycentric) ---
                if np.any(inside):
                    t_idx = tri_idx[inside]
                    # The 3 vertices for each segment's triangle
                    v0 = self.mesh[t_idx, 0]
                    v1 = self.mesh[t_idx, 1]
                    v2 = self.mesh[t_idx, 2]
                    
                    # Spatial weights
                    bw0 = bary[inside, 0]
                    bw1 = bary[inside, 1]
                    bw2 = bary[inside, 2]
                    
                    # Altitude variables for inside points
                    a0_in = a_idx0[inside]
                    a1_in = a_idx1[inside]
                    aw0_in = aw0[inside]
                    aw1_in = aw1[inside]
                    dl_in = dl_m_v[inside]
                    
                    # Flattened state index = (altitude_index * n_geo) + geo_vertex
                    
                    # Distribute to the lower altitude plane (k)
                    np.add.at(H[i], a0_in * n_geo + v0, dl_in * bw0 * aw0_in)
                    np.add.at(H[i], a0_in * n_geo + v1, dl_in * bw1 * aw0_in)
                    np.add.at(H[i], a0_in * n_geo + v2, dl_in * bw2 * aw0_in)
                    
                    # Distribute to the upper altitude plane (k+1)
                    np.add.at(H[i], a1_in * n_geo + v0, dl_in * bw0 * aw1_in)
                    np.add.at(H[i], a1_in * n_geo + v1, dl_in * bw1 * aw1_in)
                    np.add.at(H[i], a1_in * n_geo + v2, dl_in * bw2 * aw1_in)

                # --- B. Handle points OUTSIDE the mesh (Nearest Neighbor Fallback) ---
                if np.any(outside):
                    # Query KDTree for the single closest vertex (weight = 1.0)
                    _, near_v = tree.query(np.column_stack([lats_v[outside], lons_v[outside]]))
                    
                    a0_out = a_idx0[outside]
                    a1_out = a_idx1[outside]
                    aw0_out = aw0[outside]
                    aw1_out = aw1[outside]
                    dl_out = dl_m_v[outside]
                    
                    # Distribute entirely to the nearest vertical column
                    np.add.at(H[i], a0_out * n_geo + near_v, dl_out * aw0_out)
                    np.add.at(H[i], a1_out * n_geo + near_v, dl_out * aw1_out)

        # Convert final integral path lengths to TEC Units (1 TECU = 1e16)
        H /= 1e16
        
        return H
    
    
    def forward_model_mesh_tec(self, podTc2_data: dict, sample_idx: int = 0, num_segments: int = 1000) -> np.ndarray:
            """
            Simulate Total Electron Content (TEC) for radio occultation rays through the EDP mesh.
            
            Parameters
            ----------
            podTc2_data : dict
                Dictionary containing 'LEO' and 'GNSS' ECEF coordinate arrays (shape 3 x N).
            sample_idx : int, default 0
                Index of the sampling parameter to use from the EDPs array.
            num_segments : int, default 1000
                Number of segments to divide each ray into for integration.
                
            Returns
            -------
            np.ndarray
                Calculated TEC values (in TECU) for each occultation ray.
            """
            # 1. Extract Mesh and EDP Data using class properties
            altitude = self.altitude                      # 1D array of heights (km)
            geolocation = self.geolocation                # (n_geo, 2) array [lon, lat]
            raw_edps = self.edps[:, :, sample_idx].T      # Transpose to (n_geo, n_height)
            edps_2d = np.nan_to_num(raw_edps, nan=0.0)
            n_geo = edps_2d.shape[0]

            # 2. Extract Satellite Geometry
            LEO = podTc2_data['LEO']
            GNSS = podTc2_data['GNSS']
            n_rays = LEO.shape[1]

            TEC = np.zeros(n_rays)

            transformer = pyproj.Transformer.from_crs(
                pyproj.CRS.from_proj4("+proj=geocent +ellps=WGS84 +datum=WGS84"),
                pyproj.CRS.from_proj4("+proj=longlat +ellps=WGS84 +datum=WGS84"),
                always_xy=True
            )

            if n_geo == 1:
                # Spherical symmetry: single EDP profile assumed valid at all
                # horizontal positions — only altitude matters.
                print("Single-point EDP: using spherical symmetry for TEC integration.")
                ne_profile = edps_2d[0, :]   # shape: (n_height,)

                for i in tqdm(range(n_rays), desc="Processing Occultation Rays"):
                    t = np.linspace(0, 1, num_segments)
                    ray_points = GNSS[:, i:i+1] + (LEO[:, i:i+1] - GNSS[:, i:i+1]) * t

                    diffs = np.diff(ray_points, axis=1)
                    dl_km = np.linalg.norm(diffs, axis=0)
                    dl_m = dl_km * 1000.0

                    midpoints = (ray_points[:, :-1] + ray_points[:, 1:]) / 2.0

                    _, _, alts_m = transformer.transform(
                        midpoints[0, :] * 1e3,
                        midpoints[1, :] * 1e3,
                        midpoints[2, :] * 1e3
                    )
                    alts_km = alts_m / 1000.0

                    # Single profile: vectorised altitude interpolation, no spatial step
                    Ne_along_ray = np.interp(alts_km, altitude, ne_profile,
                                             left=0.0, right=0.0)

                    tec_ray = np.nansum(Ne_along_ray * dl_m)
                    TEC[i] = tec_ray / 1e16

            else:
                # Multi-point mesh: build 2-D spatial interpolators then do altitude lookup.
                print("Building spatial interpolators for the occultation mesh...")

                # Project to azimuthal equidistant centred on the mesh — fixes
                # lon/lat distortion near the poles and gives a proper metric space.
                centroid_lon = float(np.mean(geolocation[:, 0]))
                centroid_lat = float(np.mean(geolocation[:, 1]))
                proj = pyproj.Proj(proj='aeqd', lat_0=centroid_lat,
                                   lon_0=centroid_lon, ellps='WGS84')
                geo_x, geo_y = proj(geolocation[:, 0], geolocation[:, 1])
                geo_xy = np.column_stack([geo_x, geo_y])

                # Maximum distance (m) beyond the mesh boundary to trust nearest-neighbour.
                # Points further than this are set to zero instead of extrapolated.
                mesh_tree = cKDTree(geo_xy)
                max_extrap_m = 500_000.0   # 500 km — tune to your mesh size

                spatial_interp_lin  = LinearNDInterpolator(geo_xy, edps_2d)
                spatial_interp_near = NearestNDInterpolator(geo_xy, edps_2d)

                # 3. Ray Tracing & Integration
                for i in tqdm(range(n_rays), desc="Processing Occultation Rays"):

                    t = np.linspace(0, 1, num_segments)
                    ray_points = GNSS[:, i:i+1] + (LEO[:, i:i+1] - GNSS[:, i:i+1]) * t

                    diffs = np.diff(ray_points, axis=1)
                    dl_km = np.linalg.norm(diffs, axis=0)
                    dl_m = dl_km * 1000.0

                    midpoints = (ray_points[:, :-1] + ray_points[:, 1:]) / 2.0

                    lons, lats, alts_m = transformer.transform(
                        midpoints[0, :] * 1e3,
                        midpoints[1, :] * 1e3,
                        midpoints[2, :] * 1e3
                    )
                    alts_km = alts_m / 1000.0

                    # 4. Interpolate Electron Density with Hybrid Fallback
                    ray_x, ray_y = proj(lons, lats)
                    ray_profiles = spatial_interp_lin(ray_x, ray_y)

                    nan_mask = np.isnan(ray_profiles[:, 0])
                    if np.any(nan_mask):
                        out_xy = np.column_stack([ray_x[nan_mask], ray_y[nan_mask]])
                        dists, _ = mesh_tree.query(out_xy)
                        ray_profiles[nan_mask, :] = spatial_interp_near(
                            ray_x[nan_mask], ray_y[nan_mask]
                        )
                        # Zero out segments too far outside the mesh boundary
                        ray_profiles[nan_mask, :] = np.where(
                            dists[:, np.newaxis] > max_extrap_m, 0.0,
                            ray_profiles[nan_mask, :]
                        )

                    Ne_along_ray = np.zeros(num_segments - 1)
                    for j in range(num_segments - 1):
                        Ne_along_ray[j] = np.interp(
                            alts_km[j], altitude, ray_profiles[j, :],
                            left=0.0, right=0.0
                        )

                    # 5. Integrate to calculate TEC (Ne * dl)
                    tec_ray = np.nansum(Ne_along_ray * dl_m)
                    TEC[i] = tec_ray / 1e16

            return TEC

        
    @property
    def altitude(self) -> xr.DataArray:
        """1D altitude coordinate along ``height``."""
        ds = self.coords[self.COORD_ALTITUDE]
        return ds.to_numpy()

    @property
    def geolocation(self) -> xr.DataArray:
        """(geo, 2): latitude and longitude per point."""
        ds=self[self.VAR_GEOLOCATION]
        return ds.to_numpy()

    @property
    def sampling_parameters(self) -> xr.DataArray:
        """(sample, param); ``param`` labels columns (e.g. f107, ig)."""
        ds_xr = self[self.VAR_SAMPLING]
        ds=ds_xr.to_dataframe().unstack()
        ds=ds.reset_index()
        ds.columns=ds.columns.droplevel(0)
        ds=ds.drop(ds.columns[0],axis=1)
        attrs_list = self.attrs["sample_param_attrs"]
        for attrs_field in attrs_list:
             ds.attrs[attrs_field] = self.attrs[attrs_field]       
        return ds

    @property
    def edps(self) -> xr.DataArray:
        """Main field (height, geo, sample)."""
        ds = self[self.VAR_EDPS]
        return ds.to_numpy()

    @property
    def feature_edps(self) -> xr.DataArray:
        """Main field (height, geo, sample)."""
        ds = self[self.VAR_FEDPS]
        return ds.to_numpy()

    @property
    def mesh(self) -> xr.DataArray | None:
        """(triangle, 3) vertex indices into ``geo``, or ``None`` if absent."""
        if self.VAR_MESH in self.data_vars:
            ds=self[self.VAR_MESH]
            return ds.to_numpy()
        return None

    def subset_region(
        self,
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
        clip_pts: tuple | None = None,
        clip_margin_deg: float = 5.0,
    ) -> "EDPSamples":
        """
        Return a new EDPSamples containing only vertices within the lat/lon bounding box,
        optionally further clipped to a spherical triangle footprint.

        Mesh triangles with any vertex outside the selection are dropped and the
        remaining vertex indices are compacted. Handles antimeridian crossing
        when lon_min > lon_max (e.g. lon_min=170, lon_max=-170).

        Parameters
        ----------
        lat_min, lat_max : float
            Latitude bounds (degrees).
        lon_min, lon_max : float
            Longitude bounds (degrees). If lon_min > lon_max the region wraps
            across ±180°.
        clip_pts : tuple of 3 (lat, lon) pairs, optional
            If provided, vertices that pass the bounding-box test are further
            filtered to those inside or within clip_margin_deg of the spherical
            triangle defined by these three points.  Intended for use with the
            (pt1, pt2, pt3) output of EDPSamples.get_occultation_extrema so that
            only vertices geometrically under the ray-path footprint are kept.
        clip_margin_deg : float, default 5.0
            Angular buffer (degrees) around the triangle edges.  Vertices within
            this angular distance of any edge are kept even if strictly outside.
            Increase if subset_region raises due to too few remaining vertices.
        """
        geo = self.geolocation          # (n_geo, 2): col 0 = lon, col 1 = lat
        lon_g, lat_g = geo[:, 0], geo[:, 1]

        lat_mask = (lat_g >= lat_min) & (lat_g <= lat_max)
        if lon_min <= lon_max:
            lon_mask = (lon_g >= lon_min) & (lon_g <= lon_max)
        else:                            # wraps antimeridian
            lon_mask = (lon_g >= lon_min) | (lon_g <= lon_max)

        kept = np.where(lat_mask & lon_mask)[0]
        if len(kept) < 3:
            raise ValueError(
                f"subset_region: only {len(kept)} vertices in "
                f"lat=[{lat_min},{lat_max}], lon=[{lon_min},{lon_max}]"
            )

        if clip_pts is not None:
            # Secondary filter: keep only vertices geometrically under the occultation
            # triangle, expanded by clip_margin_deg so edge-adjacent nodes aren't lost.
            # geolocation col 0 = lon, col 1 = lat (consistent with lon_g/lat_g above).
            tri_mask = _inside_spherical_triangle_with_margin(
                geo[kept, 1], geo[kept, 0],
                clip_pts[0], clip_pts[1], clip_pts[2],
                margin_deg=clip_margin_deg,
            )
            kept = kept[tri_mask]
            if len(kept) < 3:
                raise ValueError(
                    f"subset_region (triangle clip): only {len(kept)} vertices "
                    f"inside the occultation triangle with {clip_margin_deg}° margin. "
                    f"Increase clip_margin_deg or widen the bounding box."
                )

        # Compact index map: old global idx → new local idx (-1 = not kept)
        remap = np.full(geo.shape[0], -1, dtype=np.int64)
        remap[kept] = np.arange(len(kept), dtype=np.int64)

        # Keep only triangles whose 3 vertices are all inside the bbox
        parent_mesh = self.mesh
        if parent_mesh is not None:
            tri_mask = np.all(remap[parent_mesh] >= 0, axis=1)
            sub_mesh = remap[parent_mesh[tri_mask]]
        else:
            sub_mesh = None

        sub_geo   = geo[kept]
        sub_edps  = self.edps[:, kept, :]
        sub_fedps = self.feature_edps[:, kept, :]

        sp = self.sampling_parameters
        sp_values = sp.to_numpy()
        sp_names  = sp.columns

        coords = {
            self.COORD_ALTITUDE: (self.DIM_HEIGHT, self.altitude),
            self.DIM_GEO_COMPONENT: (
                self.DIM_GEO_COMPONENT,
                np.array(["latitude", "longitude"], dtype=object)),
            self.DIM_PARAM:    (self.DIM_PARAM,    sp_names),
            self.DIM_FEATURE:  (self.DIM_FEATURE,  np.array(self.FEATURE_LABEL)),
        }

        data_vars = {
            self.VAR_GEOLOCATION: (
                (self.DIM_GEO, self.DIM_GEO_COMPONENT), sub_geo,
                {"long_name": "geolocation",
                 "description": "latitude (column 0), longitude (column 1)"}),
            self.VAR_EDPS: (
                (self.DIM_HEIGHT, self.DIM_GEO, self.DIM_SAMPLE), sub_edps,
                {"long_name": "EDPs",
                 "description": "electron density profiles samples"}),
            self.VAR_FEDPS: (
                (self.DIM_FEATURE, self.DIM_GEO, self.DIM_SAMPLE), sub_fedps,
                {"long_name": "Feature_EDPs",
                 "description": "features of electron density profiles samples"}),
            self.VAR_SAMPLING: (
                (self.DIM_SAMPLE, self.DIM_PARAM), sp_values,
                {"long_name": "sampling_parameters"}),
        }
        if sub_mesh is not None:
            data_vars[self.VAR_MESH] = (
                (self.DIM_TRIANGLE, self.DIM_VERTEX), sub_mesh,
                {"long_name": "surface mesh",
                 "description": "triangles: three vertex indices into the geo dimension"})

        attrs = dict(self.attrs)

        # Bypass EDPSamples.__init__ (which regenerates geometry from geo_type params)
        # and directly initialise the xarray Dataset state.
        instance = object.__new__(type(self))
        xr.Dataset.__init__(instance, data_vars=data_vars, coords=coords, attrs=attrs)
        return instance

    def subset_union_triangles(
        self,
        triangles: list[tuple],
        margin_deg: float = 2.0,
    ) -> "EDPSamples":
        """
        Return a new EDPSamples containing only vertices that fall inside the
        **union** of a list of spherical triangles, each defined by three
        (lat, lon) corner points (as returned by get_occultation_extrema).

        A vertex is kept if it is inside or within margin_deg of *any* triangle.
        Mesh triangles with any vertex outside the union are dropped.

        Parameters
        ----------
        triangles : list of (pt1, pt2, pt3) where each pt is (lat_deg, lon_deg)
        margin_deg : float
            Angular buffer around each triangle's edges (degrees).
        """
        geo     = self.geolocation          # (n_geo, 2): col 0 = lon, col 1 = lat
        lat_g   = geo[:, 1]
        lon_g   = geo[:, 0]
        union_mask = np.zeros(geo.shape[0], dtype=bool)
        for (p1, p2, p3) in triangles:
            union_mask |= _inside_spherical_triangle_with_margin(
                lat_g, lon_g, p1, p2, p3, margin_deg=margin_deg
            )

        kept = np.where(union_mask)[0]
        if len(kept) < 3:
            raise ValueError(
                f"subset_union_triangles: only {len(kept)} vertices in the union "
                f"of {len(triangles)} triangle(s) with {margin_deg}° margin. "
                f"Increase margin_deg or add more occultations."
            )

        remap = np.full(geo.shape[0], -1, dtype=np.int64)
        remap[kept] = np.arange(len(kept), dtype=np.int64)

        parent_mesh = self.mesh
        if parent_mesh is not None:
            tri_mask = np.all(remap[parent_mesh] >= 0, axis=1)
            sub_mesh = remap[parent_mesh[tri_mask]]
        else:
            sub_mesh = None

        sub_geo   = geo[kept]
        sub_edps  = self.edps[:, kept, :]
        sub_fedps = self.feature_edps[:, kept, :]

        sp = self.sampling_parameters
        sp_values = sp.to_numpy()
        sp_names  = sp.columns

        coords = {
            self.COORD_ALTITUDE: (self.DIM_HEIGHT, self.altitude),
            self.DIM_GEO_COMPONENT: (
                self.DIM_GEO_COMPONENT,
                np.array(["latitude", "longitude"], dtype=object)),
            self.DIM_PARAM:    (self.DIM_PARAM,    sp_names),
            self.DIM_FEATURE:  (self.DIM_FEATURE,  np.array(self.FEATURE_LABEL)),
        }

        data_vars = {
            self.VAR_GEOLOCATION: (
                (self.DIM_GEO, self.DIM_GEO_COMPONENT), sub_geo,
                {"long_name": "geolocation",
                 "description": "latitude (column 0), longitude (column 1)"}),
            self.VAR_EDPS: (
                (self.DIM_HEIGHT, self.DIM_GEO, self.DIM_SAMPLE), sub_edps,
                {"long_name": "EDPs",
                 "description": "electron density profiles samples"}),
            self.VAR_FEDPS: (
                (self.DIM_FEATURE, self.DIM_GEO, self.DIM_SAMPLE), sub_fedps,
                {"long_name": "Feature_EDPs",
                 "description": "feature electron density profiles samples"}),
            self.VAR_SAMPLING: (
                (self.DIM_SAMPLE, self.DIM_PARAM), sp_values,
                {"long_name": "sampling_parameters"}),
        }
        if sub_mesh is not None:
            data_vars[self.VAR_MESH] = (
                (self.DIM_TRIANGLE, self.DIM_VERTEX), sub_mesh,
                {"long_name": "surface mesh",
                 "description": "triangles: three vertex indices into the geo dimension"})

        attrs = dict(self.attrs)
        instance = object.__new__(type(self))
        xr.Dataset.__init__(instance, data_vars=data_vars, coords=coords, attrs=attrs)
        return instance

    def plot_edp_statistics(self, TitleName="Non-Gaussian"):
        """
        Plots a 3-panel statistical overview of this EDPSamples dataset using robust
        non-Gaussian percentiles.
        """
        from matplotlib.colors import LogNorm
        
        # Extract data from the dataset instance
        altitude = self.altitude
        edps = self.edps 
        
        percentiles = np.nanpercentile(edps, [1, 5, 16, 50, 84, 95, 99], axis=(1, 2))
        p01, p05, p16, median_edp, p84, p95, p99 = percentiles
        
        safe_median = np.where(median_edp == 0, np.nan, median_edp)

        fig, axes = plt.subplots(1, 3, figsize=(16, 7), sharey=True)
        fig.suptitle(f"EDP Ensemble Statistics ({TitleName})", fontsize=16, fontweight='bold', y=0.95)

        # ---------------------------------------------------------
        # Subplot 1: Absolute Median and Percentile Ranges
        # ---------------------------------------------------------
        ax1 = axes[0]
        ax1.fill_betweenx(altitude, p01, p99, color='lightblue', alpha=0.3, label='1st–99th %ile')
        ax1.fill_betweenx(altitude, p05, p95, color='dodgerblue', alpha=0.5, label='5th–95th %ile')
        ax1.fill_betweenx(altitude, p16, p84, color='blue', alpha=0.7, label='16th–84th %ile')
        ax1.plot(median_edp, altitude, color='black', lw=2, label='Median EDP')
        
        ax1.set_ylim([0, 700])
        ax1.set_xlabel("Electron Density (m⁻³)")
        ax1.set_ylabel("Altitude (km)")
        ax1.set_title("Absolute Profile Spread")
        ax1.grid(True, alpha=0.4, linestyle=':')
        ax1.legend(loc='lower right')

        # ---------------------------------------------------------
        # Subplot 2: Normalized Spread (Percentage Deviation from Median)
        # ---------------------------------------------------------
        ax2 = axes[1]
        ax2.axvline(0, color='black', lw=2, label='Median (Baseline)')
        
        def norm_pct(p_array):
            return (p_array - safe_median) / safe_median * 100

        ax2.fill_betweenx(altitude, norm_pct(p01), norm_pct(p99), color='lightcoral', alpha=0.3, label='1st–99th %ile')
        ax2.fill_betweenx(altitude, norm_pct(p05), norm_pct(p95), color='indianred', alpha=0.5, label='5th–95th %ile')
        ax2.fill_betweenx(altitude, norm_pct(p16), norm_pct(p84), color='darkred', alpha=0.7, label='16th–84th %ile')

        ax2.set_ylim([0, 700])
        ax2.set_xlabel("Deviation from Median (%)")
        ax2.set_title("Normalized Profile Spread")
        ax2.grid(True, alpha=0.4, linestyle=':')
        
        max_plot_pct = np.nanmax(np.abs(norm_pct(p95))) 
        ax2.set_xlim(-max_plot_pct, max_plot_pct)
        ax2.legend(loc='lower right')

        # ---------------------------------------------------------
        # Subplot 3: 2D Probability Density Histogram
        # ---------------------------------------------------------
        ax3 = axes[2]
        ax3.set_facecolor('black') 
        
        n_profiles = edps.shape[1] * edps.shape[2]
        flat_alts = np.tile(altitude, n_profiles)
        flat_edps = edps.reshape(len(altitude), -1).flatten(order='F')
        
        valid_mask = ~np.isnan(flat_edps)
        
        h = ax3.hist2d(flat_edps[valid_mask], flat_alts[valid_mask], 
                       bins=[60, len(altitude)], cmap='viridis', norm=LogNorm())
        
        ax3.plot(median_edp, altitude, color='white', lw=1.5, linestyle='--', label='Median')

        ax3.set_ylim([0, 700])
        ax3.set_xlabel("Electron Density (m⁻³)")
        ax3.set_title("True Ensemble Probability Density")
        cbar = fig.colorbar(h[3], ax=ax3)
        cbar.set_label('Count (Density)')
        ax3.grid(True, alpha=0.3, color='white', linestyle=':')
        ax3.legend(loc='lower right')

        plt.tight_layout()
        # plt.show()

    def plot_edp_covariance(self, ref_alt_idx: int = None, ref_geo_idx: int = None):
            """
            Memory-efficient covariance analysis using the ensemble perturbation matrix.

            Never forms the full (n_state_vars × n_state_vars) matrix. Instead stores
            P_sqrt of shape (n_state_vars, n_sample) such that C = P_sqrt @ P_sqrt.T.
            For n_sample << n_state_vars this saves orders of magnitude of RAM.

            Plots:
              - Standard deviation at each state variable (n_height × n_geo heatmap)
              - Pearson correlation from a chosen reference state variable

            Parameters
            ----------
            ref_alt_idx : int, optional
                Altitude index of the reference state variable. Defaults to the
                altitude of maximum mean Ne (F-region peak).
            ref_geo_idx : int, optional
                Geo-point index of the reference state variable. Defaults to the
                centre geo point.

            Returns
            -------
            P_sqrt : np.ndarray, shape (n_state_vars, n_sample)
                Square-root covariance factor. Full covariance is P_sqrt @ P_sqrt.T.
            std_map : np.ndarray, shape (n_height, n_geo)
                Standard deviation at every state variable.
            corr_map : np.ndarray, shape (n_height, n_geo)
                Pearson correlation with the reference state variable.
            """
            from matplotlib.colors import LogNorm

            edps = self.edps.astype(np.float32)
            n_height, n_geo, n_sample = edps.shape
            n_state_vars = n_height * n_geo

            full_mb  = n_state_vars ** 2 * 4 / 1e6
            sqrt_mb  = n_state_vars * n_sample * 4 / 1e6
            print(f"  -> State vector : {n_state_vars} variables  "
                  f"({n_height} heights × {n_geo} geo points)")
            print(f"  -> Ensemble size: {n_sample} samples")
            print(f"  -> Memory — full matrix: {full_mb:.0f} MB  |  "
                  f"P_sqrt factor: {sqrt_mb:.1f} MB")

            # Flatten to (n_state_vars, n_sample)
            X = edps.reshape(n_state_vars, n_sample)

            # Mean-centre; treat NaNs as zero perturbation so they don't inflate variance
            X_mean = np.nanmean(X, axis=1, keepdims=True)
            X_c    = np.where(np.isnan(X), 0.0, X - X_mean).astype(np.float32)

            # C = P_sqrt @ P_sqrt.T  (never formed explicitly)
            P_sqrt = X_c / np.sqrt(max(n_sample - 1, 1))

            # --- Standard deviation (square root of diagonal of C) ---
            # var[i] = ||P_sqrt[i,:]||^2  — one elementwise square + row sum
            std_map = np.sqrt(np.sum(P_sqrt ** 2, axis=1)).reshape(n_height, n_geo)

            # --- Reference state variable ---
            if ref_geo_idx is None:
                ref_geo_idx = n_geo // 2
            if ref_alt_idx is None:
                mean_profile = X_mean.reshape(n_height, n_geo).mean(axis=1)
                ref_alt_idx  = int(np.argmax(mean_profile))

            ref_idx = ref_alt_idx * n_geo + ref_geo_idx
            print(f"  -> Reference state: alt idx={ref_alt_idx}, "
                  f"geo idx={ref_geo_idx}  (flat idx={ref_idx})")

            # corr[i] = (P_sqrt[ref] · P_sqrt[i]) / (||P_sqrt[ref]|| · ||P_sqrt[i]||)
            # Only one (n_state_vars,) matmul needed — no full matrix formed
            ref_row    = P_sqrt[ref_idx, :]                        # (n_sample,)
            dot_prods  = P_sqrt @ ref_row                          # (n_state_vars,)
            ref_norm   = float(np.linalg.norm(ref_row))
            row_norms  = np.linalg.norm(P_sqrt, axis=1)           # (n_state_vars,)

            with np.errstate(divide='ignore', invalid='ignore'):
                corr_row = dot_prods / (ref_norm * row_norms)
            corr_map = np.nan_to_num(corr_row, nan=0.0).reshape(n_height, n_geo)

            # ---------------------------------------------------------
            # Plot
            # ---------------------------------------------------------
            fig, axes = plt.subplots(1, 2, figsize=(14, 5))
            fig.suptitle(
                f"EDP Ensemble Statistics  "
                f"({n_height} heights × {n_geo} geo pts, {n_sample} samples)",
                fontsize=14, fontweight='bold'
            )

            # Panel 1: standard deviation map
            ax1 = axes[0]
            im1 = ax1.pcolormesh(std_map, cmap='plasma')
            ax1.set_title("Standard Deviation (Ne, m⁻³)")
            ax1.set_xlabel("Geo Point Index")
            ax1.set_ylabel("Altitude Index")
            ax1.invert_yaxis()
            fig.colorbar(im1, ax=ax1, label="Std Dev (m⁻³)")

            # Panel 2: correlation from reference point
            ax2 = axes[1]
            im2 = ax2.pcolormesh(corr_map, cmap='coolwarm', vmin=-1, vmax=1)
            ax2.set_title(
                f"Pearson Correlation from Reference\n"
                f"(alt idx={ref_alt_idx}, geo idx={ref_geo_idx})"
            )
            ax2.set_xlabel("Geo Point Index")
            ax2.set_ylabel("Altitude Index")
            ax2.invert_yaxis()
            ax2.plot(ref_geo_idx, ref_alt_idx, 'k*', markersize=10,
                     label='Reference point')
            ax2.legend(loc='upper right')
            fig.colorbar(im2, ax=ax2, label="Pearson Correlation")

            plt.tight_layout()
            # plt.show()

            return P_sqrt, std_map, corr_map